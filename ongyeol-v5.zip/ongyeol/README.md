# 온결 관리자 시스템 — XAMPP MySQL 버전

---

## 사전 설치 (최초 1회)

### 1. Node.js 설치
https://nodejs.org → **LTS 버전** 다운로드 및 설치  
설치 후 VS Code를 **완전히 닫았다가 다시 열기**

### 2. XAMPP 설치
https://www.apachefriends.org → 다운로드 및 설치  
설치 후 **XAMPP Control Panel** 실행 → **MySQL** 옆 [Start] 클릭

---

## 실행 방법

VS Code에서 `ongyeol` 폴더를 열고 터미널(Ctrl + `) 에서 순서대로 입력:

```bash
# 1단계 — 라이브러리 설치
npm run install:all

# 2단계 — 데이터베이스 + 테이블 생성 + 샘플 데이터 삽입
npm run db:init

# 3단계 — 개발 서버 실행
npm run dev
```

브라우저에서 http://localhost:3000 접속

**로그인 계정**
- 이메일: `admin@ongyeol.go.kr`
- 비밀번호: `Admin1234!`

---

## phpMyAdmin에서 DB 확인

XAMPP Control Panel → MySQL 옆 [Admin] 클릭  
→ 브라우저에서 phpMyAdmin 열림  
→ 왼쪽 목록에서 `ongyeol_db` 클릭  
→ 테이블 직접 확인 및 편집 가능

---

## 환경 변수 (.env)

`backend/.env.example` → `backend/.env` 로 복사 후 수정  
XAMPP 기본값은 수정 없이 사용 가능:

```
DB_HOST=localhost
DB_PORT=3306
DB_NAME=ongyeol_db
DB_USER=root
DB_PASSWORD=        ← XAMPP 기본값은 빈칸
```

phpMyAdmin에서 root 비밀번호를 설정했다면 DB_PASSWORD에 입력.

---

## 프로젝트 구조

```
ongyeol/
├── backend/
│   ├── config/database.js      MySQL 연결 (mysql2)
│   ├── database/init.js        DB·테이블 자동 생성 + 샘플 데이터
│   ├── middleware/auth.js       JWT 인증
│   ├── routes/
│   │   ├── auth.js             로그인·계정 관리
│   │   ├── dashboard.js        종합 관제
│   │   ├── members.js          수혜자 관리
│   │   └── alerts.js           알림·조치 일지
│   ├── server.js
│   └── .env.example
│
├── frontend/
│   └── src/
│       ├── pages/
│       │   ├── LoginPage.jsx
│       │   ├── DashboardPage.jsx
│       │   ├── MembersPage.jsx
│       │   └── AlertsPage.jsx
│       ├── components/
│       │   ├── layout/Sidebar.jsx
│       │   └── members/RegisterMemberModal.jsx
│       ├── hooks/useAuthStore.js
│       └── utils/api.js
│
└── package.json
```

---

## MySQL 테이블 구조

| 테이블 | 설명 |
|--------|------|
| `admins` | 관리자 계정 |
| `members` | 독거 수혜 가구 |
| `devices` | IoT 슬림 스틱 |
| `wellness_reports` | AI 웰니스 리포트 |
| `alerts` | 긴급 알림 |
| `incident_logs` | 조치 일지 |
