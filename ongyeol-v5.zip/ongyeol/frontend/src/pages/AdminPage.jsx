import React, { useState, useEffect, useCallback } from 'react';
import { Shield, Check, X, Clock, RefreshCw, UserPlus, Mail } from 'lucide-react';
import api from '../utils/api';

const ROLE_LABELS = { super_admin:'슈퍼관리자', local_gov:'지자체 담당자', welfare_worker:'복지 담당사' };

function PendingRow({ account, onApprove, onReject }) {
  const [role, setRole] = useState('welfare_worker');
  const [loading, setLoading] = useState(false);

  const handleApprove = async () => {
    setLoading(true);
    await onApprove(account.id, role);
    setLoading(false);
  };

  const handleReject = async () => {
    if (!window.confirm(`${account.name}님의 계정 신청을 거절하시겠습니까?`)) return;
    setLoading(true);
    await onReject(account.id);
    setLoading(false);
  };

  return (
    <tr>
      <td>
        <div style={{fontWeight:600,color:'var(--text-primary)'}}>{account.name}</div>
        <div style={{fontSize:11,color:'var(--text-muted)'}}>{account.department}</div>
      </td>
      <td style={{fontSize:12}}>
        <div style={{display:'flex',alignItems:'center',gap:5}}>
          <Mail size={12} color="var(--text-muted)"/>
          {account.email}
        </div>
      </td>
      <td style={{fontSize:12,color:'var(--text-secondary)'}}>{account.phone || '-'}</td>
      <td style={{fontSize:11,color:'var(--text-muted)'}}>
        {new Date(account.created_at).toLocaleString('ko-KR',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}
      </td>
      <td>
        <select className="input" style={{width:130,fontSize:12,padding:'5px 8px'}} value={role} onChange={e=>setRole(e.target.value)}>
          <option value="welfare_worker">복지 담당사</option>
          <option value="local_gov">지자체 담당자</option>
          <option value="super_admin">슈퍼관리자</option>
        </select>
      </td>
      <td>
        <div style={{display:'flex',gap:6}}>
          <button className="btn btn-success" style={{padding:'5px 10px',fontSize:12}} onClick={handleApprove} disabled={loading}>
            <Check size={13}/> 승인
          </button>
          <button className="btn btn-danger" style={{padding:'5px 10px',fontSize:12}} onClick={handleReject} disabled={loading}>
            <X size={13}/> 거절
          </button>
        </div>
      </td>
    </tr>
  );
}

export default function AdminPage() {
  const [pending, setPending] = useState([]);
  const [allAdmins, setAllAdmins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('pending');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [pendingRes, allRes] = await Promise.all([
        api.get('/auth/pending'),
        api.get('/auth/admins'),
      ]);
      setPending(pendingRes.data);
      setAllAdmins(allRes.data.filter(a => a.is_active));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleApprove = async (id, role) => {
    try {
      await api.patch(`/auth/approve/${id}`, { role, approved: true });
      alert('✅ 승인됐습니다. 가입자 이메일로 알림이 발송됐습니다.');
      fetchData();
    } catch (err) {
      alert('승인 실패: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleReject = async (id) => {
    try {
      await api.patch(`/auth/approve/${id}`, { approved: false });
      alert('거절됐습니다.');
      fetchData();
    } catch (err) {
      alert('처리 실패: ' + (err.response?.data?.error || err.message));
    }
  };

  const handleDeactivate = async (id, name) => {
    if (!window.confirm(`${name}님 계정을 비활성화하시겠습니까?`)) return;
    try {
      await api.patch(`/auth/admins/${id}/deactivate`);
      fetchData();
    } catch (err) {
      alert('처리 실패');
    }
  };

  const TABS = [
    { id:'pending', label:`승인 대기 ${pending.length ? `(${pending.length})` : ''}`, icon:Clock },
    { id:'all',     label:'전체 계정 목록', icon:Shield },
  ];

  return (
    <div className="fade-in">
      <div className="page-header">
        <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between'}}>
          <div>
            <h1>권한 관리</h1>
            <p>계정 신청 승인 및 담당자 권한 관리</p>
          </div>
          <button onClick={fetchData} className="btn btn-secondary" style={{marginBottom:16}}>
            <RefreshCw size={13}/> 새로고침
          </button>
        </div>

        {/* 탭 */}
        <div style={{display:'flex',gap:0}}>
          {TABS.map(({id,label,icon:Icon})=>(
            <button key={id} onClick={()=>setTab(id)} style={{
              padding:'10px 18px',background:'none',border:'none',cursor:'pointer',
              display:'flex',alignItems:'center',gap:6,fontSize:13,
              fontWeight:tab===id?700:400,
              color:tab===id?'var(--text-primary)':'var(--text-secondary)',
              borderBottom:`2px solid ${tab===id?'var(--accent)':'transparent'}`,
              transition:'all .15s',
            }}>
              <Icon size={14}/>{label}
            </button>
          ))}
        </div>
      </div>

      <div className="page-body">

        {/* 승인 대기 */}
        {tab === 'pending' && (
          <>
            {pending.length > 0 && (
              <div style={{padding:'10px 14px',background:'#fffbeb',border:'1px solid #fde68a',borderRadius:8,marginBottom:16,display:'flex',alignItems:'center',gap:8,fontSize:13,color:'#92400e'}}>
                <Clock size={14}/>
                <strong>{pending.length}명</strong>의 계정 신청이 승인을 기다리고 있습니다. 승인 시 가입자 이메일로 자동 알림이 발송됩니다.
              </div>
            )}

            <div className="card" style={{padding:0,overflow:'hidden'}}>
              {loading
                ? <div className="loading-center"><div className="spinner"/><span>불러오는 중...</span></div>
                : (
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>이름 / 소속</th>
                        <th>이메일</th>
                        <th>연락처</th>
                        <th>신청 일시</th>
                        <th>부여할 권한</th>
                        <th>처리</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pending.length === 0
                        ? <tr><td colSpan={6} style={{textAlign:'center',color:'var(--text-muted)',padding:48}}>
                            <UserPlus size={28} style={{display:'block',margin:'0 auto 10px',opacity:.3}}/>
                            승인 대기 중인 계정이 없습니다
                          </td></tr>
                        : pending.map(acc => (
                          <PendingRow
                            key={acc.id}
                            account={acc}
                            onApprove={handleApprove}
                            onReject={handleReject}
                          />
                        ))
                      }
                    </tbody>
                  </table>
                )
              }
            </div>
          </>
        )}

        {/* 전체 계정 목록 */}
        {tab === 'all' && (
          <div className="card" style={{padding:0,overflow:'hidden'}}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>이름</th>
                  <th>이메일</th>
                  <th>역할</th>
                  <th>소속</th>
                  <th>연락처</th>
                  <th>마지막 로그인</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {allAdmins.map(a => (
                  <tr key={a.id}>
                    <td style={{fontWeight:600}}>{a.name}</td>
                    <td style={{fontSize:12,color:'var(--text-secondary)'}}>{a.email}</td>
                    <td>
                      <span className={`badge badge-${a.role==='super_admin'?'blue':a.role==='local_gov'?'yellow':'gray'}`}>
                        {ROLE_LABELS[a.role]}
                      </span>
                    </td>
                    <td style={{fontSize:12,color:'var(--text-secondary)'}}>{a.department||'-'}</td>
                    <td style={{fontSize:12,color:'var(--text-secondary)'}}>{a.phone||'-'}</td>
                    <td style={{fontSize:11,color:'var(--text-muted)'}}>
                      {a.last_login ? new Date(a.last_login).toLocaleString('ko-KR',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}) : '없음'}
                    </td>
                    <td>
                      {a.role !== 'super_admin' && (
                        <button className="btn btn-danger" style={{padding:'4px 10px',fontSize:11}}
                          onClick={()=>handleDeactivate(a.id,a.name)}>
                          비활성화
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
