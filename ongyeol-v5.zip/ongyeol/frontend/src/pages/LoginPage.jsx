import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import useAuthStore from '../hooks/useAuthStore';
import { Activity, Eye, EyeOff, Shield, Lock, Mail } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPw] = useState('');
  const [showPw, setShowPw] = useState(false);
  const { login, loading, error, user, clearError } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => { if (user) navigate('/dashboard', { replace:true }); }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault(); clearError();
    if (await login(email, password)) navigate('/dashboard', { replace:true });
  };

  return (
    <div style={{ minHeight:'100vh', background:'var(--bg-primary)', display:'flex', alignItems:'center', justifyContent:'center', padding:16 }}>
      <div style={{ position:'fixed', inset:0, pointerEvents:'none', background:'radial-gradient(ellipse 60% 50% at 50% -10%,rgba(31,111,235,.15),transparent)' }} />
      <div style={{ width:'100%', maxWidth:400, position:'relative' }}>
        <div style={{ textAlign:'center', marginBottom:32 }}>
          <div style={{ width:56, height:56, background:'linear-gradient(135deg,#1f6feb,#388bfd)', borderRadius:14, display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 16px', boxShadow:'0 0 32px rgba(31,111,235,.35)' }}>
            <Activity size={28} color="#fff" />
          </div>
          <h1 style={{ fontSize:26, fontWeight:800, color:'var(--text-primary)', marginBottom:6, letterSpacing:'-0.03em' }}>온결 관리자 시스템</h1>
          <p style={{ fontSize:13, color:'var(--text-secondary)' }}>독거 노인 안전 지원 플랫폼 · XAMPP MySQL</p>
        </div>

        <div className="card" style={{ padding:28 }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, padding:'8px 12px', background:'rgba(31,111,235,.1)', border:'1px solid rgba(31,111,235,.25)', borderRadius:'var(--radius-md)', marginBottom:22 }}>
            <Shield size={13} color="var(--accent-hover)" />
            <span style={{ fontSize:12, color:'var(--accent-hover)' }}>지자체 인증 보안 접속 · JWT 2차 보안</span>
          </div>

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom:16 }}>
              <label className="label">이메일 계정</label>
              <div style={{ position:'relative' }}>
                <Mail size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text-muted)' }} />
                <input className="input" style={{ paddingLeft:34 }} type="email" placeholder="admin@ongyeol.go.kr" value={email} onChange={e=>setEmail(e.target.value)} required />
              </div>
            </div>
            <div style={{ marginBottom:20 }}>
              <label className="label">비밀번호</label>
              <div style={{ position:'relative' }}>
                <Lock size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'var(--text-muted)' }} />
                <input className="input" style={{ paddingLeft:34, paddingRight:38 }} type={showPw?'text':'password'} placeholder="비밀번호 입력" value={password} onChange={e=>setPw(e.target.value)} required />
                <button type="button" onClick={()=>setShowPw(v=>!v)} style={{ position:'absolute', right:10, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', display:'flex' }}>
                  {showPw ? <EyeOff size={15}/> : <Eye size={15}/>}
                </button>
              </div>
            </div>
            {error && <div style={{ padding:'10px 14px', background:'var(--risk-red-bg)', border:'1px solid rgba(248,81,73,.3)', borderRadius:'var(--radius-md)', color:'var(--risk-red)', fontSize:13, marginBottom:16 }}>{error}</div>}
            <button type="submit" className="btn btn-primary" style={{ width:'100%', justifyContent:'center', padding:'11px 16px', fontSize:14 }} disabled={loading}>
              {loading ? <><div className="spinner" style={{ width:16, height:16 }}/> 인증 중...</> : '로그인'}
            </button>
          </form>
        </div>
        <p style={{ textAlign:'center', fontSize:11, color:'var(--text-muted)', marginTop:16 }}>계정 문의: 시스템 관리자 · phpMyAdmin에서 관리</p>
        <p style={{ textAlign:'center', fontSize:12, color:'#6b7280', marginTop:10 }}>
          계정이 없으신가요?{' '}
          <Link to="/register" style={{ color:'#2563eb', fontWeight:600, textDecoration:'none' }}>계정 신청</Link>
        </p>
      </div>
    </div>
  );
}
