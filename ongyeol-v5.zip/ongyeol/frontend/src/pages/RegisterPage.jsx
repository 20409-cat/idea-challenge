import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Activity, User, Mail, Lock, Phone, Building, Eye, EyeOff, CheckCircle } from 'lucide-react';
import api from '../utils/api';

const FIELDS = [
  { key: 'name',       label: '이름',       type: 'text',     placeholder: '홍길동',              icon: User     },
  { key: 'email',      label: '이메일',     type: 'email',    placeholder: 'hong@ongyeol.go.kr',  icon: Mail     },
  { key: 'department', label: '소속 부서',  type: 'text',     placeholder: '독거노인지원팀',        icon: Building },
  { key: 'phone',      label: '연락처',     type: 'tel',      placeholder: '010-0000-0000',        icon: Phone    },
];

export default function RegisterPage() {
  const [form, setForm]     = useState({ name:'', email:'', password:'', passwordCheck:'', department:'', phone:'' });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');
  const [done,    setDone]    = useState(false);
  const navigate = useNavigate();

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const validate = () => {
    if (!form.name || !form.email || !form.password)
      return '이름, 이메일, 비밀번호는 필수입니다.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      return '이메일 형식이 올바르지 않습니다.';
    if (form.password.length < 8)
      return '비밀번호는 8자 이상이어야 합니다.';
    if (form.password !== form.passwordCheck)
      return '비밀번호가 일치하지 않습니다.';
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const err = validate();
    if (err) { setError(err); return; }
    setError(''); setLoading(true);
    try {
      await api.post('/auth/request-account', {
        name:       form.name,
        email:      form.email,
        password:   form.password,
        department: form.department,
        phone:      form.phone,
      });
      setDone(true);
    } catch (err) {
      setError(err.response?.data?.error || '계정 신청에 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  // ── 완료 화면 ──
  if (done) return (
    <div style={{ minHeight:'100vh', background:'#f8fafc', display:'flex', alignItems:'center', justifyContent:'center', padding:16 }}>
      <div style={{ textAlign:'center', maxWidth:380 }}>
        <div style={{ width:64, height:64, borderRadius:'50%', background:'#dcfce7', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 20px' }}>
          <CheckCircle size={32} color="#16a34a" />
        </div>
        <h2 style={{ fontSize:22, fontWeight:700, color:'#111', marginBottom:10 }}>신청 완료!</h2>
        <p style={{ fontSize:14, color:'#6b7280', lineHeight:1.7, marginBottom:28 }}>
          계정 신청이 접수됐습니다.<br />
          관리자가 승인하면 로그인할 수 있습니다.<br />
          승인 여부는 담당자에게 문의하세요.
        </p>
        <button onClick={() => navigate('/login')} className="btn btn-primary" style={{ width:'100%', justifyContent:'center', padding:'11px 16px' }}>
          로그인 화면으로
        </button>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight:'100vh', background:'#f8fafc', display:'flex', alignItems:'center', justifyContent:'center', padding:16 }}>
      <div style={{ position:'fixed', inset:0, pointerEvents:'none', background:'radial-gradient(ellipse 60% 50% at 50% -10%,rgba(31,111,235,.08),transparent)' }} />

      <div style={{ width:'100%', maxWidth:440, position:'relative' }}>
        {/* 헤더 */}
        <div style={{ textAlign:'center', marginBottom:28 }}>
          <div style={{ width:52, height:52, background:'#1f6feb', borderRadius:13, display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 14px' }}>
            <Activity size={26} color="#fff" />
          </div>
          <h1 style={{ fontSize:22, fontWeight:800, color:'#111', marginBottom:4, letterSpacing:'-0.03em' }}>온결 계정 신청</h1>
          <p style={{ fontSize:13, color:'#6b7280' }}>관리자 승인 후 로그인 가능합니다</p>
        </div>

        <div style={{ background:'#fff', border:'1px solid #e5e7eb', borderRadius:14, padding:28, boxShadow:'0 1px 4px rgba(0,0,0,.06)' }}>
          {/* 안내 배너 */}
          <div style={{ background:'#eff6ff', border:'1px solid #bfdbfe', borderRadius:8, padding:'9px 13px', marginBottom:22, fontSize:12, color:'#1d4ed8' }}>
            복지 담당자 계정만 신청 가능합니다. 신청 후 슈퍼관리자 승인이 필요합니다.
          </div>

          <form onSubmit={handleSubmit}>
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

              {/* 일반 필드들 */}
              {FIELDS.map(({ key, label, type, placeholder, icon: Icon }) => (
                <div key={key}>
                  <label className="label">{label}{['name','email'].includes(key) ? ' *' : ''}</label>
                  <div style={{ position:'relative' }}>
                    <Icon size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#9ca3af' }} />
                    <input
                      className="input"
                      style={{ paddingLeft:34 }}
                      type={type}
                      placeholder={placeholder}
                      value={form[key]}
                      onChange={e => set(key, e.target.value)}
                      required={['name','email'].includes(key)}
                    />
                  </div>
                </div>
              ))}

              {/* 비밀번호 */}
              <div>
                <label className="label">비밀번호 * <span style={{ fontWeight:400, textTransform:'none', letterSpacing:0 }}>(8자 이상)</span></label>
                <div style={{ position:'relative' }}>
                  <Lock size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#9ca3af' }} />
                  <input
                    className="input"
                    style={{ paddingLeft:34, paddingRight:38 }}
                    type={showPw ? 'text' : 'password'}
                    placeholder="비밀번호 입력"
                    value={form.password}
                    onChange={e => set('password', e.target.value)}
                    required
                  />
                  <button type="button" onClick={() => setShowPw(v => !v)}
                    style={{ position:'absolute', right:10, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#9ca3af', display:'flex' }}>
                    {showPw ? <EyeOff size={15}/> : <Eye size={15}/>}
                  </button>
                </div>
              </div>

              {/* 비밀번호 확인 */}
              <div>
                <label className="label">비밀번호 확인 *</label>
                <div style={{ position:'relative' }}>
                  <Lock size={14} style={{ position:'absolute', left:12, top:'50%', transform:'translateY(-50%)', color:'#9ca3af' }} />
                  <input
                    className="input"
                    style={{
                      paddingLeft:34,
                      borderColor: form.passwordCheck && form.password !== form.passwordCheck ? '#dc2626' : undefined,
                    }}
                    type={showPw ? 'text' : 'password'}
                    placeholder="비밀번호 재입력"
                    value={form.passwordCheck}
                    onChange={e => set('passwordCheck', e.target.value)}
                    required
                  />
                  {form.passwordCheck && form.password === form.passwordCheck && (
                    <CheckCircle size={15} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', color:'#16a34a' }} />
                  )}
                </div>
                {form.passwordCheck && form.password !== form.passwordCheck && (
                  <div style={{ fontSize:11, color:'#dc2626', marginTop:4 }}>비밀번호가 일치하지 않습니다</div>
                )}
              </div>

            </div>

            {error && (
              <div style={{ marginTop:14, padding:'10px 13px', background:'#fef2f2', border:'1px solid #fecaca', borderRadius:8, color:'#b91c1c', fontSize:13 }}>
                {error}
              </div>
            )}

            <button
              type="submit"
              className="btn btn-primary"
              style={{ width:'100%', justifyContent:'center', padding:'11px 16px', fontSize:14, marginTop:18 }}
              disabled={loading}
            >
              {loading ? <><div className="spinner" style={{ width:16, height:16 }} /> 신청 중...</> : '계정 신청'}
            </button>
          </form>
        </div>

        <p style={{ textAlign:'center', fontSize:12, color:'#9ca3af', marginTop:16 }}>
          이미 계정이 있으신가요?{' '}
          <Link to="/login" style={{ color:'#2563eb', fontWeight:600, textDecoration:'none' }}>로그인</Link>
        </p>
      </div>
    </div>
  );
}
