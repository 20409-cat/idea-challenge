import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Plus, Wifi, WifiOff, BatteryLow, ChevronRight } from 'lucide-react';
import api from '../utils/api';
import RegisterMemberModal from '../components/members/RegisterMemberModal';

const RISK_LABELS = { red:'위험', yellow:'주의', green:'안전' };
const calcAge = b => { const d=new Date(b),t=new Date(); return t.getFullYear()-d.getFullYear(); };

export default function MembersPage() {
  const [members, setMembers] = useState([]);
  const [total, setTotal]   = useState(0);
  const [loading, setLoading] = useState(true);
  const [showReg, setShowReg] = useState(false);
  const [filters, setFilters] = useState({ search:'', risk_level:'', district:'' });
  const [page, setPage] = useState(1);
  const navigate = useNavigate();

  const fetchMembers = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit:25, ...filters };
      Object.keys(params).forEach(k => !params[k] && delete params[k]);
      const res = await api.get('/members', { params });
      setMembers(res.data.data); setTotal(res.data.total);
    } catch(e){ console.error(e); } finally { setLoading(false); }
  },[filters,page]);

  useEffect(()=>{ fetchMembers(); },[fetchMembers]);
  const setFilter = (k,v) => { setFilters(p=>({...p,[k]:v})); setPage(1); };

  return (
    <div className="fade-in">
      <div className="page-header">
        <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between'}}>
          <div><h1>수혜자(독거 가구) 관리</h1><p>신규 가구 등록, 디바이스 연동, 담당자 지정 및 리포트 조회</p></div>
          <button onClick={()=>setShowReg(true)} className="btn btn-primary" style={{marginBottom:16}}><Plus size={14}/> 신규 가구 등록</button>
        </div>
      </div>

      <div className="page-body">
        <div style={{display:'flex',gap:10,marginBottom:16,flexWrap:'wrap'}}>
          <div style={{position:'relative',flex:'1 1 240px'}}>
            <Search size={14} style={{position:'absolute',left:10,top:'50%',transform:'translateY(-50%)',color:'var(--text-muted)'}}/>
            <input className="input" style={{paddingLeft:32}} placeholder="이름, 주소 검색..." value={filters.search} onChange={e=>setFilter('search',e.target.value)}/>
          </div>
          <select className="input" style={{width:130}} value={filters.risk_level} onChange={e=>setFilter('risk_level',e.target.value)}>
            <option value="">전체 위험도</option>
            <option value="red">🔴 위험</option>
            <option value="yellow">🟡 주의</option>
            <option value="green">🟢 안전</option>
          </select>
          <input className="input" style={{width:140}} placeholder="구 필터 (예: 해운대구)" value={filters.district} onChange={e=>setFilter('district',e.target.value)}/>
        </div>

        <div style={{fontSize:12,color:'var(--text-muted)',marginBottom:12}}>
          총 <strong style={{color:'var(--text-primary)'}}>{total}</strong>명
        </div>

        <div className="card" style={{padding:0,overflow:'hidden'}}>
          {loading
            ? <div className="loading-center"><div className="spinner"/><span>불러오는 중...</span></div>
            : <div style={{overflowX:'auto'}}>
                <table className="data-table">
                  <thead><tr>
                    <th>이름 / 나이</th><th>위험도</th><th>주소 / 구역</th>
                    <th>담당 복지사</th><th>디바이스</th><th>웰니스</th><th>비상 연락처</th><th></th>
                  </tr></thead>
                  <tbody>
                    {members.length===0
                      ? <tr><td colSpan={8} style={{textAlign:'center',color:'var(--text-muted)',padding:40}}>조건에 맞는 수혜자가 없습니다</td></tr>
                      : members.map(m=>(
                        <tr key={m.id} onClick={()=>navigate(`/members/${m.id}`)}>
                          <td>
                            <div style={{display:'flex',alignItems:'center',gap:8}}>
                              <div style={{width:30,height:30,borderRadius:'50%',background:'var(--bg-hover)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,fontWeight:700,flexShrink:0}}>{m.name[0]}</div>
                              <div><div style={{fontWeight:600}}>{m.name}</div><div style={{fontSize:11,color:'var(--text-muted)'}}>{m.birth_date?`${calcAge(m.birth_date)}세`:'-'}</div></div>
                            </div>
                          </td>
                          <td><span className={`badge badge-${m.risk_level}`}>{RISK_LABELS[m.risk_level]}</span></td>
                          <td><div style={{fontSize:12}}>{m.address}</div><div style={{fontSize:11,color:'var(--text-muted)'}}>{m.district}</div></td>
                          <td style={{fontSize:12,color:m.welfare_worker_name?'var(--text-primary)':'var(--text-muted)'}}>{m.welfare_worker_name||'미지정'}</td>
                          <td>
                            {m.device_serial
                              ? <div style={{display:'flex',alignItems:'center',gap:6}}>
                                  {m.device_online?<Wifi size={13} color="var(--risk-green)"/>:<WifiOff size={13} color="var(--text-muted)"/>}
                                  <span style={{fontSize:11,color:'var(--text-secondary)'}}>{String(m.device_serial).slice(-6)}</span>
                                  {m.battery_level<20&&<BatteryLow size={12} color="var(--risk-yellow)"/>}
                                </div>
                              : <span style={{fontSize:11,color:'var(--text-muted)'}}>미연동</span>
                            }
                          </td>
                          <td>
                            {m.overall_score
                              ? <div style={{display:'flex',alignItems:'center',gap:6}}>
                                  <div style={{width:60,height:6,background:'var(--border)',borderRadius:3,overflow:'hidden'}}>
                                    <div style={{width:`${m.overall_score}%`,height:'100%',background:m.overall_score>70?'var(--risk-green)':m.overall_score>50?'var(--risk-yellow)':'var(--risk-red)'}}/>
                                  </div>
                                  <span style={{fontSize:11,color:'var(--text-secondary)'}}>{m.overall_score}</span>
                                </div>
                              : <span style={{fontSize:11,color:'var(--text-muted)'}}>—</span>
                            }
                          </td>
                          <td><div>{m.emergency_contact_name}</div><div style={{fontSize:11,color:'var(--text-muted)'}}>{m.emergency_contact_phone}</div></td>
                          <td><ChevronRight size={14} color="var(--text-muted)"/></td>
                        </tr>
                      ))
                    }
                  </tbody>
                </table>
              </div>
          }
          {total>25&&(
            <div style={{padding:'12px 18px',borderTop:'1px solid var(--border)',display:'flex',gap:8,justifyContent:'flex-end'}}>
              <button className="btn btn-secondary" style={{padding:'5px 12px'}} disabled={page===1} onClick={()=>setPage(p=>p-1)}>이전</button>
              <span style={{display:'flex',alignItems:'center',fontSize:12,color:'var(--text-secondary)'}}>{page}/{Math.ceil(total/25)}</span>
              <button className="btn btn-secondary" style={{padding:'5px 12px'}} disabled={page>=Math.ceil(total/25)} onClick={()=>setPage(p=>p+1)}>다음</button>
            </div>
          )}
        </div>
      </div>

      {showReg&&<RegisterMemberModal onClose={()=>setShowReg(false)} onSuccess={()=>{setShowReg(false);fetchMembers();}}/>}
    </div>
  );
}
