import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, Users, Wifi, RefreshCw, Map, Eye } from 'lucide-react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import api from '../utils/api';

const RISK_COLORS = { red:'#f85149', yellow:'#e3b341', green:'#3fb950' };
const RISK_LABELS  = { red:'위험', yellow:'주의', green:'안전' };

function StatCard({ label, value, sub, color, icon:Icon }) {
  return (
    <div className="card" style={{ display:'flex', alignItems:'center', gap:14 }}>
      <div style={{ width:44, height:44, borderRadius:10, background:`${color}22`, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
        <Icon size={20} color={color} />
      </div>
      <div>
        <div style={{ fontSize:24, fontWeight:800, lineHeight:1 }}>{value ?? '—'}</div>
        <div style={{ fontSize:12, color:'var(--text-secondary)', marginTop:3 }}>{label}</div>
        {sub && <div style={{ fontSize:11, color, marginTop:2 }}>{sub}</div>}
      </div>
    </div>
  );
}

function DigitalTwinView({ members }) {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !members.length) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width, H = canvas.height;
    let frame;
    const districts = [...new Set(members.map(m => m.district))];
    const cols = Math.ceil(Math.sqrt(districts.length));
    function draw(t) {
      ctx.clearRect(0,0,W,H);
      ctx.strokeStyle='rgba(48,54,61,.5)'; ctx.lineWidth=0.5;
      for(let x=0;x<W;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}
      for(let y=0;y<H;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
      districts.forEach((district,di)=>{
        const dm=members.filter(m=>m.district===district);
        const col=di%cols,row=Math.floor(di/cols);
        const bw=(W-60)/cols, bh=(H-60)/Math.ceil(districts.length/cols);
        const bx=30+col*bw, by=30+row*bh, cx=bx+bw/2, cy=by+bh/2;
        ctx.fillStyle='rgba(139,148,158,.6)'; ctx.font='10px sans-serif'; ctx.textAlign='center';
        ctx.fillText(district,cx,by+14);
        dm.forEach((m,mi)=>{
          const angle=(mi/dm.length)*Math.PI*2;
          const r=Math.min(bw,bh)*.3;
          const nx=cx+Math.cos(angle+t*.0003)*r, ny=cy+Math.sin(angle+t*.0003)*r;
          const color=RISK_COLORS[m.risk_level]||'#3fb950';
          const pulse=.7+.3*Math.sin(t*.002+mi);
          ctx.strokeStyle=`${color}33`; ctx.lineWidth=.5;
          ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(nx,ny);ctx.stroke();
          const grad=ctx.createRadialGradient(nx,ny,0,nx,ny,16*pulse);
          grad.addColorStop(0,`${color}55`);grad.addColorStop(1,'transparent');
          ctx.fillStyle=grad;ctx.beginPath();ctx.arc(nx,ny,16*pulse,0,Math.PI*2);ctx.fill();
          ctx.fillStyle=color;ctx.beginPath();ctx.arc(nx,ny,4,0,Math.PI*2);ctx.fill();
        });
        const hasRed=dm.some(m=>m.risk_level==='red');
        ctx.strokeStyle=hasRed?'rgba(248,81,73,.4)':'rgba(48,54,61,.6)';
        ctx.lineWidth=hasRed?1:.5;
        ctx.strokeRect(bx+4,by+18,bw-8,bh-22);
      });
      frame=requestAnimationFrame(draw);
    }
    frame=requestAnimationFrame(draw);
    return ()=>cancelAnimationFrame(frame);
  },[members]);
  return <canvas ref={canvasRef} width={600} height={380} style={{width:'100%',height:'100%',display:'block'}} />;
}

export default function DashboardPage() {
  const [summary, setSummary] = useState(null);
  const [mapData, setMapData] = useState([]);
  const [alerts,  setAlerts]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('map');
  const navigate = useNavigate();

  const fetchData = useCallback(async () => {
    try {
      const [s,m,a] = await Promise.all([
        api.get('/dashboard/summary'),
        api.get('/dashboard/members-map'),
        api.get('/dashboard/recent-alerts'),
      ]);
      setSummary(s.data); setMapData(m.data); setAlerts(a.data);
    } catch(e){ console.error(e); } finally { setLoading(false); }
  },[]);

  useEffect(()=>{ fetchData(); const i=setInterval(fetchData,30000); return()=>clearInterval(i); },[fetchData]);

  const pieData = summary ? [
    {name:'위험',  value:parseInt(summary.members.red_count),    color:'#f85149'},
    {name:'주의',  value:parseInt(summary.members.yellow_count), color:'#e3b341'},
    {name:'안전',  value:parseInt(summary.members.green_count),  color:'#3fb950'},
  ] : [];

  const criticalAlerts = alerts.filter(a=>!a.is_resolved&&a.severity==='critical');

  if(loading) return <div className="loading-center"><div className="spinner" style={{width:28,height:28}}/><span>데이터 불러오는 중...</span></div>;

  return (
    <div className="fade-in">
      <div className="page-header">
        <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between'}}>
          <div><h1>실시간 종합 관제</h1><p>전체 독거 가구의 안전 상태를 실시간으로 모니터링합니다</p></div>
          <div style={{display:'flex',gap:8,paddingBottom:16}}>
            <button onClick={()=>setView(v=>v==='map'?'list':'map')} className="btn btn-secondary">
              {view==='map'?<><Eye size={14}/> 목록</>:<><Map size={14}/> 맵</>}
            </button>
            <button onClick={fetchData} className="btn btn-secondary"><RefreshCw size={14}/> 새로고침</button>
          </div>
        </div>
      </div>

      <div className="page-body">
        {criticalAlerts.length>0&&(
          <div style={{padding:'12px 16px',background:'var(--risk-red-bg)',border:'1px solid rgba(248,81,73,.4)',borderRadius:'var(--radius-md)',marginBottom:20,display:'flex',alignItems:'center',gap:10}}>
            <AlertTriangle size={16} color="var(--risk-red)"/>
            <span style={{color:'var(--risk-red)',fontWeight:600,fontSize:13}}>긴급 위급상황 {criticalAlerts.length}건 처리 대기 중</span>
            <button onClick={()=>navigate('/alerts')} className="btn btn-danger" style={{marginLeft:'auto',padding:'5px 12px'}}>알림 확인</button>
          </div>
        )}

        <div className="grid-4" style={{marginBottom:20}}>
          <StatCard label="전체 수혜 가구" value={summary?.members.total} color="var(--accent)" icon={Users}/>
          <StatCard label="위험 가구" value={summary?.members.red_count} sub={parseInt(summary?.members.red_count)>0?'즉각 확인 필요':undefined} color="#f85149" icon={AlertTriangle}/>
          <StatCard label="기기 온라인" value={summary?.devices.online} sub={`/ 전체 ${summary?.devices.total}대`} color="#3fb950" icon={Wifi}/>
          <StatCard label="미처리 알림" value={summary?.alerts.unresolved} sub={parseInt(summary?.alerts.critical)>0?`긴급 ${summary.alerts.critical}건`:undefined} color={parseInt(summary?.alerts.critical)>0?'#f85149':'#e3b341'} icon={AlertTriangle}/>
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 300px',gap:16}}>
          <div className="card" style={{padding:0,overflow:'hidden'}}>
            <div style={{padding:'14px 18px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <div>
                <div style={{fontWeight:700}}>{view==='map'?'🌐 디지털 트윈 모니터링':'📋 가구별 위험도 현황'}</div>
                <div style={{fontSize:11,color:'var(--text-muted)',marginTop:2}}>구역별 실시간 위험 인디케이터</div>
              </div>
              <div style={{display:'flex',gap:6}}>
                {['red','yellow','green'].map(r=>(
                  <span key={r} className={`badge badge-${r}`}>{RISK_LABELS[r]} {summary?.members[`${r}_count`]}</span>
                ))}
              </div>
            </div>
            {view==='map'
              ? <div style={{height:380}}><DigitalTwinView members={mapData}/></div>
              : <div style={{maxHeight:400,overflowY:'auto',padding:'10px 14px'}}>
                  {mapData.map(m=>(
                    <div key={m.id} onClick={()=>navigate(`/members/${m.id}`)}
                      style={{display:'flex',alignItems:'center',gap:12,padding:'10px 12px',borderRadius:'var(--radius-md)',background:'var(--bg-hover)',border:`1px solid ${m.risk_level==='red'?'rgba(248,81,73,.3)':'var(--border)'}`,cursor:'pointer',marginBottom:6}}>
                      <div style={{width:10,height:10,borderRadius:'50%',background:RISK_COLORS[m.risk_level],boxShadow:`0 0 8px ${RISK_COLORS[m.risk_level]}`,flexShrink:0}}/>
                      <div style={{flex:1}}><div style={{fontWeight:600,fontSize:13}}>{m.name}</div><div style={{fontSize:11,color:'var(--text-muted)'}}>{m.district}</div></div>
                      <span className={`badge badge-${m.risk_level}`} style={{fontSize:10}}>{RISK_LABELS[m.risk_level]}</span>
                    </div>
                  ))}
                </div>
            }
          </div>

          <div style={{display:'flex',flexDirection:'column',gap:16}}>
            <div className="card">
              <div style={{fontWeight:700,marginBottom:14,fontSize:13}}>위험도 분포</div>
              <div style={{height:140}}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart><Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={60} dataKey="value" paddingAngle={3}>
                    {pieData.map((e,i)=><Cell key={i} fill={e.color}/>)}
                  </Pie><Tooltip contentStyle={{background:'var(--bg-card)',border:'1px solid var(--border)',borderRadius:8}}/></PieChart>
                </ResponsiveContainer>
              </div>
              <div style={{display:'flex',justifyContent:'center',gap:12}}>
                {pieData.map(d=>(
                  <div key={d.name} style={{display:'flex',alignItems:'center',gap:5,fontSize:12}}>
                    <div style={{width:8,height:8,borderRadius:'50%',background:d.color}}/><span style={{color:'var(--text-secondary)'}}>{d.name} {d.value}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="card" style={{flex:1}}>
              <div style={{fontWeight:700,marginBottom:12,fontSize:13}}>최근 알림</div>
              {alerts.slice(0,6).map(a=>(
                <div key={a.id} style={{padding:'8px 10px',background:'var(--bg-hover)',borderRadius:'var(--radius-sm)',borderLeft:`3px solid ${a.severity==='critical'?'#f85149':a.severity==='warning'?'#e3b341':'#3fb950'}`,marginBottom:6}}>
                  <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:2}}>
                    <span style={{fontWeight:600,fontSize:12}}>{a.member_name}</span>
                    {!a.is_resolved&&<span style={{fontSize:10,color:'#f85149',fontWeight:700}}>미처리</span>}
                  </div>
                  <div style={{fontSize:11,color:'var(--text-secondary)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{a.message}</div>
                </div>
              ))}
              {alerts.length===0&&<div style={{color:'var(--text-muted)',fontSize:12,textAlign:'center',padding:16}}>알림이 없습니다</div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
