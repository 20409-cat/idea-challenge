import React, { useState, useEffect, useCallback } from 'react';
import { AlertTriangle, CheckCircle, Clock, Smartphone, FileText, RefreshCw, Plus, Bell } from 'lucide-react';
import api from '../utils/api';

const SEV  = { critical:'긴급', warning:'주의', info:'일반' };
const ATYPE = { no_movement:'움직임 없음', fall_detected:'낙상 감지', sos:'SOS 호출', low_battery:'배터리 부족', offline:'기기 오프라인', abnormal_pattern:'이상 패턴' };
const fmt  = ts => ts ? new Date(ts).toLocaleString('ko-KR',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}) : '-';

// ── 알림 생성 모달 ──
function CreateAlertModal({ onClose, onSuccess }) {
  const [members, setMembers] = useState([]);
  const [form, setForm] = useState({
    member_id: '',
    alert_type: 'no_movement',
    severity: 'critical',
    message: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/members', { params: { limit: 100 } })
      .then(res => setMembers(res.data.data || []))
      .catch(() => {});
  }, []);

  const ALERT_TYPES = [
    { value: 'no_movement',      label: '움직임 없음' },
    { value: 'fall_detected',    label: '낙상 감지' },
    { value: 'sos',              label: 'SOS 호출' },
    { value: 'low_battery',      label: '배터리 부족' },
    { value: 'offline',          label: '기기 오프라인' },
    { value: 'abnormal_pattern', label: '이상 패턴 감지' },
    { value: 'other',            label: '기타' },
  ];

  // 알림 유형 선택 시 기본 메시지 자동 입력
  const handleTypeChange = (type) => {
    const defaults = {
      no_movement:      '8시간 이상 움직임이 감지되지 않습니다.',
      fall_detected:    '낙상이 감지됐습니다. 즉각 확인이 필요합니다.',
      sos:              'SOS 버튼이 눌렸습니다. 긴급 확인이 필요합니다.',
      low_battery:      '디바이스 배터리가 20% 미만입니다.',
      offline:          '디바이스가 오프라인 상태입니다.',
      abnormal_pattern: '비정상적인 생활 패턴이 감지됐습니다.',
    };
    setForm(p => ({ ...p, alert_type: type, message: defaults[type] || '' }));
  };

  const handleSubmit = async () => {
    if (!form.member_id) { setError('수혜자를 선택하세요.'); return; }
    if (!form.message)   { setError('메시지를 입력하세요.'); return; }
    setLoading(true); setError('');
    try {
      await api.post('/alerts', form);
      onSuccess();
    } catch (err) {
      setError(err.response?.data?.error || '알림 생성에 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ width:32, height:32, borderRadius:8, background:'var(--risk-red-bg)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <Bell size={16} color="var(--risk-red)" />
            </div>
            <h2>긴급 알림 생성</h2>
          </div>
          <button onClick={onClose} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', fontSize:18 }}>✕</button>
        </div>

        <div className="modal-body">
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

            {/* 수혜자 선택 */}
            <div>
              <label className="label">수혜자 선택 *</label>
              <select className="input" value={form.member_id}
                onChange={e => setForm(p => ({ ...p, member_id: e.target.value }))}>
                <option value="">— 수혜자를 선택하세요 —</option>
                {members.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.name} · {m.district} ({m.risk_level === 'red' ? '🔴' : m.risk_level === 'yellow' ? '🟡' : '🟢'})
                  </option>
                ))}
              </select>
            </div>

            {/* 심각도 */}
            <div>
              <label className="label">심각도 *</label>
              <div style={{ display:'flex', gap:8 }}>
                {[
                  { value:'critical', label:'🔴 긴급', color:'var(--risk-red)',    bg:'var(--risk-red-bg)',    border:'var(--risk-red-border)' },
                  { value:'warning',  label:'🟡 주의', color:'var(--risk-yellow)', bg:'var(--risk-yellow-bg)', border:'var(--risk-yellow-border)' },
                  { value:'info',     label:'⚪ 일반', color:'var(--text-secondary)', bg:'var(--bg-hover)',   border:'var(--border)' },
                ].map(({ value, label, color, bg, border }) => (
                  <button key={value} type="button"
                    onClick={() => setForm(p => ({ ...p, severity: value }))}
                    style={{
                      flex:1, padding:'8px', borderRadius:'var(--radius-md)',
                      border: `1.5px solid ${form.severity === value ? color : 'var(--border)'}`,
                      background: form.severity === value ? bg : 'var(--bg-card)',
                      color: form.severity === value ? color : 'var(--text-secondary)',
                      fontWeight: form.severity === value ? 700 : 400,
                      cursor:'pointer', fontSize:13, transition:'all .15s',
                    }}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* 알림 유형 */}
            <div>
              <label className="label">알림 유형 *</label>
              <select className="input" value={form.alert_type} onChange={e => handleTypeChange(e.target.value)}>
                {ALERT_TYPES.map(({ value, label }) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </div>

            {/* 메시지 */}
            <div>
              <label className="label">메시지 *</label>
              <textarea
                className="input"
                style={{ minHeight:80, resize:'vertical' }}
                placeholder="알림 내용을 입력하세요..."
                value={form.message}
                onChange={e => setForm(p => ({ ...p, message: e.target.value }))}
              />
            </div>

            {/* 안내 */}
            {form.severity === 'critical' && (
              <div style={{ padding:'10px 13px', background:'var(--risk-red-bg)', border:'1px solid var(--risk-red-border)', borderRadius:'var(--radius-md)', fontSize:12, color:'var(--risk-red)' }}>
                🚨 긴급 알림 생성 시 — 전체 관리자 이메일 발송 + 보호자 이메일 자동 발송 + 푸시 알림이 전송됩니다.
              </div>
            )}

            {error && (
              <div style={{ padding:'10px 13px', background:'var(--risk-red-bg)', border:'1px solid var(--risk-red-border)', borderRadius:'var(--radius-md)', fontSize:13, color:'var(--risk-red)' }}>
                {error}
              </div>
            )}
          </div>
        </div>

        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>취소</button>
          <button className="btn btn-primary" onClick={handleSubmit} disabled={loading}
            style={{ background: form.severity === 'critical' ? 'var(--risk-red)' : undefined }}>
            {loading
              ? <><div className="spinner" style={{ width:14, height:14 }} /> 생성 중...</>
              : <><Plus size={14} /> 알림 생성</>
            }
          </button>
        </div>
      </div>
    </div>
  );
}

function ResolveModal({ alert, onClose, onSuccess }) {
  const [form, setForm] = useState({ resolution_note:'', action_taken:'', contacted_emergency:false, visit_required:false, outcome:'정상 처리' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!form.action_taken) return;
    setLoading(true);
    try { await api.patch(`/alerts/${alert.id}/resolve`, form); onSuccess(); }
    catch { alert('처리 실패'); setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal">
        <div className="modal-header"><h2>알림 처리 · 조치 일지 작성</h2><button onClick={onClose} style={{background:'none',border:'none',cursor:'pointer',color:'var(--text-muted)'}}>✕</button></div>
        <div className="modal-body">
          <div style={{padding:'10px 14px',background:'var(--risk-red-bg)',borderRadius:8,marginBottom:16,fontSize:13,color:'var(--risk-red)'}}>
            <strong>{alert.member_name}</strong> · {ATYPE[alert.alert_type]||alert.alert_type}<br/>
            <span style={{fontSize:12,opacity:.8}}>{alert.message}</span>
          </div>
          <div style={{display:'flex',flexDirection:'column',gap:12}}>
            <div><label className="label">조치 내용 *</label>
              <textarea className="input" style={{minHeight:80,resize:'vertical'}} placeholder="전화 확인, 방문 여부..." value={form.action_taken} onChange={e=>setForm(p=>({...p,action_taken:e.target.value}))}/>
            </div>
            <div><label className="label">처리 결과 메모</label>
              <input className="input" placeholder="별도 이상 없음 / 병원 이송 등" value={form.resolution_note} onChange={e=>setForm(p=>({...p,resolution_note:e.target.value}))}/>
            </div>
            <div><label className="label">결과 분류</label>
              <select className="input" value={form.outcome} onChange={e=>setForm(p=>({...p,outcome:e.target.value}))}>
                {['정상 처리','병원 이송','가족 연락 완료','방문 간호 요청','경찰 출동','기타'].map(o=><option key={o}>{o}</option>)}
              </select>
            </div>
            <div style={{display:'flex',gap:20}}>
              {[{key:'contacted_emergency',label:'긴급 연락처 연락 완료'},{key:'visit_required',label:'방문 필요'}].map(({key,label})=>(
                <label key={key} style={{display:'flex',alignItems:'center',gap:8,cursor:'pointer',fontSize:13}}>
                  <input type="checkbox" checked={form[key]} onChange={e=>setForm(p=>({...p,[key]:e.target.checked}))} style={{accentColor:'var(--accent)'}}/>
                  {label}
                </label>
              ))}
            </div>
          </div>
        </div>
        <div className="modal-footer">
          <button className="btn btn-secondary" onClick={onClose}>취소</button>
          <button className="btn btn-primary" onClick={handleSubmit} disabled={loading||!form.action_taken}>
            {loading?'처리 중...':'조치 완료 · 일지 저장'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AlertsPage() {
  const [alerts,  setAlerts]  = useState([]);
  const [devices, setDevices] = useState([]);
  const [logs,    setLogs]    = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab,   setTab]   = useState('alerts');
  const [fResolved,  setFResolved]  = useState('false');
  const [fSeverity,  setFSeverity]  = useState('');
  const [resolveTarget,  setResolveTarget]  = useState(null);
  const [showCreate,     setShowCreate]     = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if(fSeverity) params.severity = fSeverity;
      if(fResolved!=='') params.is_resolved = fResolved;
      const [ar,dr,lr] = await Promise.all([
        api.get('/alerts',{params}),
        api.get('/alerts/devices'),
        api.get('/alerts/incident-logs'),
      ]);
      setAlerts(ar.data); setDevices(dr.data); setLogs(lr.data);
    } catch(e){console.error(e);} finally{setLoading(false);}
  },[fResolved,fSeverity]);

  useEffect(()=>{ fetchData(); },[fetchData]);

  const TABS = [
    {id:'alerts',  label:'알림 목록',    icon:AlertTriangle},
    {id:'devices', label:'디바이스 상태', icon:Smartphone},
    {id:'logs',    label:'조치 일지',    icon:FileText},
  ];

  return (
    <div className="fade-in">
      <div className="page-header">
        <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between'}}>
          <div><h1>알림 및 장애 관리</h1><p>긴급 위급상황 처리, 조치 일지 기록, IoT 디바이스 상태 확인</p></div>
          <div style={{display:'flex',gap:8,paddingBottom:16}}>
            <button
              onClick={() => setShowCreate(true)}
              className="btn btn-primary"
              style={{ background:'var(--risk-red)' }}
            >
              <Plus size={14}/> 긴급 알림 생성
            </button>
            <button onClick={fetchData} className="btn btn-secondary"><RefreshCw size={14}/> 새로고침</button>
          </div>
        </div>
        <div style={{display:'flex',gap:0}}>
          {TABS.map(({id,label,icon:Icon})=>(
            <button key={id} onClick={()=>setTab(id)} style={{padding:'10px 18px',background:'none',border:'none',cursor:'pointer',display:'flex',alignItems:'center',gap:6,fontSize:13,fontWeight:tab===id?700:400,color:tab===id?'var(--text-primary)':'var(--text-muted)',borderBottom:`2px solid ${tab===id?'var(--accent)':'transparent'}`,transition:'all .15s'}}>
              <Icon size={14}/>{label}
            </button>
          ))}
        </div>
      </div>

      <div className="page-body">
        {tab==='alerts'&&(
          <>
            <div style={{display:'flex',gap:10,marginBottom:16}}>
              <select className="input" style={{width:150}} value={fSeverity} onChange={e=>setFSeverity(e.target.value)}>
                <option value="">전체 심각도</option>
                <option value="critical">🔴 긴급</option>
                <option value="warning">🟡 주의</option>
                <option value="info">⚪ 일반</option>
              </select>
              <select className="input" style={{width:150}} value={fResolved} onChange={e=>setFResolved(e.target.value)}>
                <option value="false">미처리</option>
                <option value="true">처리 완료</option>
                <option value="">전체</option>
              </select>
            </div>
            <div className="card" style={{padding:0,overflow:'hidden'}}>
              {loading?<div className="loading-center"><div className="spinner"/><span>불러오는 중...</span></div>
              :<table className="data-table">
                <thead><tr><th>심각도</th><th>수혜자</th><th>유형</th><th>내용</th><th>발생 시간</th><th>상태</th><th></th></tr></thead>
                <tbody>
                  {alerts.length===0?<tr><td colSpan={7} style={{textAlign:'center',color:'var(--text-muted)',padding:40}}>알림이 없습니다</td></tr>
                  :alerts.map(a=>(
                    <tr key={a.id}>
                      <td><span className={`badge badge-${a.severity==='critical'?'red':a.severity==='warning'?'yellow':'green'}`}>{SEV[a.severity]}</span></td>
                      <td><div style={{fontWeight:600,fontSize:13}}>{a.member_name}</div><div style={{fontSize:11,color:'var(--text-muted)'}}>{a.district}</div></td>
                      <td style={{fontSize:12}}>{ATYPE[a.alert_type]||a.alert_type}</td>
                      <td style={{fontSize:12,maxWidth:220}}><div style={{overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{a.message}</div></td>
                      <td style={{fontSize:11,color:'var(--text-secondary)'}}>{fmt(a.created_at)}</td>
                      <td>{a.is_resolved
                        ?<div style={{display:'flex',alignItems:'center',gap:5,fontSize:12,color:'var(--risk-green)'}}><CheckCircle size={13}/>처리 완료</div>
                        :<div style={{display:'flex',alignItems:'center',gap:5,fontSize:12,color:'var(--risk-yellow)'}}><Clock size={13}/>미처리</div>}
                      </td>
                      <td>{!a.is_resolved&&<button className="btn btn-danger" style={{padding:'4px 10px',fontSize:12}} onClick={()=>setResolveTarget(a)}>조치</button>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>}
            </div>
          </>
        )}

        {tab==='devices'&&(
          <div className="card" style={{padding:0,overflow:'hidden'}}>
            <table className="data-table">
              <thead><tr><th>시리얼 번호</th><th>수혜자</th><th>구역</th><th>온라인</th><th>배터리</th><th>마지막 신호</th><th>위치</th></tr></thead>
              <tbody>
                {devices.map(d=>(
                  <tr key={d.id||d.device_serial}>
                    <td style={{fontFamily:'var(--font-mono)',fontSize:12}}>{d.device_serial}</td>
                    <td style={{fontWeight:600,fontSize:13}}>{d.member_name||'미연동'}</td>
                    <td style={{fontSize:12,color:'var(--text-muted)'}}>{d.district}</td>
                    <td><span className={`badge badge-${d.is_online?'green':'red'}`}>{d.is_online?'온라인':'오프라인'}</span></td>
                    <td>
                      <div style={{display:'flex',alignItems:'center',gap:8}}>
                        <div style={{width:50,height:6,background:'var(--border)',borderRadius:3,overflow:'hidden'}}>
                          <div style={{width:`${d.battery_level}%`,height:'100%',background:d.battery_level<20?'#f85149':d.battery_level<50?'#e3b341':'#3fb950'}}/>
                        </div>
                        <span style={{fontSize:11,color:d.battery_level<20?'var(--risk-red)':'var(--text-secondary)'}}>{d.battery_level}%</span>
                      </div>
                    </td>
                    <td style={{fontSize:11,color:'var(--text-secondary)'}}>{fmt(d.last_ping)}</td>
                    <td style={{fontSize:12}}>{d.location_in_home}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab==='logs'&&(
          <div className="card" style={{padding:0,overflow:'hidden'}}>
            <table className="data-table">
              <thead><tr><th>일시</th><th>수혜자</th><th>처리 담당자</th><th>조치 내용</th><th>결과</th><th>긴급 연락</th><th>방문 필요</th></tr></thead>
              <tbody>
                {logs.length===0?<tr><td colSpan={7} style={{textAlign:'center',color:'var(--text-muted)',padding:40}}>조치 일지가 없습니다</td></tr>
                :logs.map(l=>(
                  <tr key={l.id}>
                    <td style={{fontSize:11,color:'var(--text-secondary)'}}>{fmt(l.logged_at)}</td>
                    <td><div style={{fontWeight:600,fontSize:13}}>{l.member_name}</div><div style={{fontSize:11,color:'var(--text-muted)'}}>{l.district}</div></td>
                    <td style={{fontSize:12}}>{l.handler_name||'-'}</td>
                    <td style={{fontSize:12,maxWidth:200}}><div style={{overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{l.action_taken}</div></td>
                    <td style={{fontSize:12}}>{l.outcome}</td>
                    <td><span className={`badge badge-${l.contacted_emergency?'green':'red'}`}>{l.contacted_emergency?'완료':'미연락'}</span></td>
                    <td><span className={`badge badge-${l.visit_required?'yellow':'green'}`}>{l.visit_required?'필요':'불필요'}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {resolveTarget&&<ResolveModal alert={resolveTarget} onClose={()=>setResolveTarget(null)} onSuccess={()=>{setResolveTarget(null);fetchData();}}/>}
      {showCreate&&<CreateAlertModal onClose={()=>setShowCreate(false)} onSuccess={()=>{setShowCreate(false);fetchData();setTab('alerts');setFResolved('false');}}/>}
    </div>
  );
}
