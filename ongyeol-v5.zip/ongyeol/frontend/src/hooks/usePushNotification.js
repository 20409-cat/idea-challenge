import { useState, useEffect, useCallback } from 'react';
import api from '../utils/api';

const VAPID_PUBLIC_KEY = process.env.REACT_APP_VAPID_PUBLIC_KEY || '';

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64  = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw     = window.atob(base64);
  return new Uint8Array([...raw].map(c => c.charCodeAt(0)));
}

export default function usePushNotification() {
  const [supported,   setSupported]   = useState(false);
  const [permission,  setPermission]  = useState('default');
  const [subscribed,  setSubscribed]  = useState(false);
  const [loading,     setLoading]     = useState(false);
  const [swReg,       setSwReg]       = useState(null);

  // Service Worker 등록
  useEffect(() => {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
    setSupported(true);
    setPermission(Notification.permission);

    navigator.serviceWorker.register('/sw.js')
      .then(reg => {
        setSwReg(reg);
        // 이미 구독 중인지 확인
        return reg.pushManager.getSubscription();
      })
      .then(sub => { if (sub) setSubscribed(true); })
      .catch(err => console.warn('SW 등록 실패:', err));
  }, []);

  // 알림 구독 요청
  const subscribe = useCallback(async () => {
    if (!swReg || !VAPID_PUBLIC_KEY) {
      alert('VAPID 키가 설정되지 않았습니다. .env 파일을 확인하세요.');
      return;
    }
    setLoading(true);
    try {
      const perm = await Notification.requestPermission();
      setPermission(perm);
      if (perm !== 'granted') return;

      const sub = await swReg.pushManager.subscribe({
        userVisibleOnly:      true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
      });

      await api.post('/push/subscribe', { subscription: sub });
      setSubscribed(true);
    } catch (err) {
      console.error('구독 실패:', err);
      alert('알림 구독에 실패했습니다: ' + err.message);
    } finally {
      setLoading(false);
    }
  }, [swReg]);

  // 구독 해제
  const unsubscribe = useCallback(async () => {
    setLoading(true);
    try {
      const sub = await swReg?.pushManager.getSubscription();
      if (sub) await sub.unsubscribe();
      await api.delete('/push/unsubscribe');
      setSubscribed(false);
    } catch (err) {
      console.error('구독 해제 실패:', err);
    } finally {
      setLoading(false);
    }
  }, [swReg]);

  // 테스트 알림 전송
  const sendTest = useCallback(async () => {
    try {
      await api.post('/push/send-test');
      alert('테스트 알림을 전송했습니다. 잠시 후 휴대폰을 확인하세요.');
    } catch (err) {
      alert('전송 실패: ' + (err.response?.data?.error || err.message));
    }
  }, []);

  return { supported, permission, subscribed, loading, subscribe, unsubscribe, sendTest };
}
