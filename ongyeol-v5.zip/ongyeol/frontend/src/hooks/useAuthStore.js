import { create } from 'zustand';
import api from '../utils/api';

const useAuthStore = create((set) => ({
  user:    JSON.parse(localStorage.getItem('ongyeol_user') || 'null'),
  token:   localStorage.getItem('ongyeol_token') || null,
  loading: false,
  error:   null,

  login: async (email, password) => {
    set({ loading: true, error: null });
    try {
      const res = await api.post('/auth/login', { email, password });
      const { token, user } = res.data;
      localStorage.setItem('ongyeol_token', token);
      localStorage.setItem('ongyeol_user', JSON.stringify(user));
      set({ token, user, loading: false });
      return true;
    } catch (err) {
      set({ error: err.response?.data?.error || '로그인에 실패했습니다.', loading: false });
      return false;
    }
  },

  logout: async () => {
    try { await api.post('/auth/logout'); } catch {}
    localStorage.removeItem('ongyeol_token');
    localStorage.removeItem('ongyeol_user');
    set({ user: null, token: null });
  },

  clearError: () => set({ error: null }),
}));

export default useAuthStore;
