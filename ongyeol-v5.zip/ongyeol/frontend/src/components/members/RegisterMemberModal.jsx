import React, { useState, useEffect } from 'react';
import { X, UserPlus, Smartphone } from 'lucide-react';
import api from '../../utils/api';

const INIT = { name:'', birth_date:'', gender:'female', address:'', district:'', phone:'', medical_notes:'', emergency_contact_name:'', emergency_contact_phone:'', emergency_contact_email:'', emergency_contact_relation:'자녀', assigned_welfare_worker_id:'', device_serial:'', device_location:'거실' };

export default function RegisterMemberModal({ onClose, onSuccess }) {
  const [form, setForm] = useState(INIT);
  const [workers, setWorkers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [step, setStep] = useState(1);

  useEffect(() => {
    api.get('/auth/admins').then(res => setWorkers(res.data.filter(a=>a.role==='welfare_worker'||a.role==='local_gov'))).catch(()=>{});
  }, []);

  const set = (k,v) => setForm(p=>({...p,[k]:v}));

  const handleSubmit = async () => {
    if (!form.name||!form.birth_date||!form.address||!form.district) { setError('필수 항목을 입력하세요.'); return; }
    setLoading(true); setError('');
    try { await api.post('/members', form); onSuccess(); }
    catch(err) { setError(err.response?.data?.error||'등록에 실패했습니다.'); }
    finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal" style={{maxWidth:600}}>
        <div className="modal-header">
          <div style={{display:'flex',alignItems:'center',gap:10}}><UserPlus size={18} color="var(--accent-hover)"/><h2>신규 독거 가구 등록</h2></div>
          <button onClick={onClose} style={{background:'none',border:'none',cursor:'pointer',color:'var(--text-muted)'}}><X size={18}/></button>
        </div>

        <div style={{display:'flex',padding:'12px 24px 0',gap:0}}>
          {['기본 정보','비상 연락','디바이스 연동'].map((label,i)=>(
            <div key={i} style={{flex:1}} onClick={()=>setStep(i+1)}>
              <div style={{display:'flex',alignItems:'center',gap:6,cursor:'pointer',padding:'6px 0',borderBottom:`2px solid ${step===i+1?'var(--accent)':'var(--border)'}`,width:'100%'}}>
                <div style={{width:20,height:20,borderRadius:'50%',fontSize:11,fontWeight:700,display:'flex',alignItems:'center',justifyContent:'center',background:step>i?'var(--accent)':'var(--bg-hover)',color:step>i?'#fff':'var(--text-muted)'}}>{i+1}</div>
                <span style={{fontSize:12,fontWeight:step===i+1?700:400,color:step===i+1?'var(--accent-hover)':'var(--text-muted)'}}>{label}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="modal-body">
          {step===1&&(
            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              <div className="grid-2">
                <div><label className="label">이름 *</label><input className="input" placeholder="홍길동" value={form.name} onChange={e=>set('name',e.target.value)}/></div>
                <div><label className="label">생년월일 *</label><input className="input" type="date" value={form.birth_date} onChange={e=>set('birth_date',e.target.value)}/></div>
              </div>
              <div className="grid-2">
                <div><label className="label">성별</label><select className="input" value={form.gender} onChange={e=>set('gender',e.target.value)}><option value="female">여성</option><option value="male">남성</option></select></div>
                <div><label className="label">연락처</label><input className="input" placeholder="010-0000-0000" value={form.phone} onChange={e=>set('phone',e.target.value)}/></div>
              </div>
              <div><label className="label">주소 *</label><input className="input" placeholder="부산시 해운대구 좌동 123" value={form.address} onChange={e=>set('address',e.target.value)}/></div>
              <div className="grid-2">
                <div><label className="label">구역(구) *</label><input className="input" placeholder="해운대구" value={form.district} onChange={e=>set('district',e.target.value)}/></div>
                <div><label className="label">담당 복지사</label>
                  <select className="input" value={form.assigned_welfare_worker_id} onChange={e=>set('assigned_welfare_worker_id',e.target.value)}>
                    <option value="">선택 안함</option>
                    {workers.map(w=><option key={w.id} value={w.id}>{w.name} ({w.department})</option>)}
                  </select>
                </div>
              </div>
              <div><label className="label">특이사항 / 의료 메모</label><textarea className="input" style={{resize:'vertical',minHeight:70}} placeholder="만성 질환, 복용 약물 등..." value={form.medical_notes} onChange={e=>set('medical_notes',e.target.value)}/></div>
            </div>
          )}

          {step===2&&(
            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              <div style={{padding:'10px 14px',background:'var(--accent-bg)',borderRadius:'var(--radius-md)',fontSize:12,color:'var(--accent-hover)'}}>긴급 상황 발생 시 즉시 연락할 보호자 정보를 입력하세요.</div>
              <div className="grid-2">
                <div><label className="label">비상 연락처 이름</label><input className="input" placeholder="홍철수" value={form.emergency_contact_name} onChange={e=>set('emergency_contact_name',e.target.value)}/></div>
                <div><label className="label">관계</label><select className="input" value={form.emergency_contact_relation} onChange={e=>set('emergency_contact_relation',e.target.value)}>{['자녀','배우자','형제자매','친인척','이웃','기타'].map(r=><option key={r}>{r}</option>)}</select></div>
              </div>
              <div><label className="label">전화번호</label><input className="input" placeholder="010-0000-0000" value={form.emergency_contact_phone} onChange={e=>set('emergency_contact_phone',e.target.value)}/></div>
              <div>
                <label className="label">보호자 이메일 <span style={{fontWeight:400,textTransform:'none',letterSpacing:0,color:'var(--text-muted)'}}>(긴급 알림 수신용)</span></label>
                <input className="input" type="email" placeholder="guardian@email.com" value={form.emergency_contact_email} onChange={e=>set('emergency_contact_email',e.target.value)}/>
                <div style={{fontSize:11,color:'var(--text-muted)',marginTop:4}}>
                  긴급 상황 발생 시 이 이메일로 자동 알림이 발송됩니다
                </div>
              </div>
            </div>
          )}

          {step===3&&(
            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              <div style={{display:'flex',alignItems:'center',gap:10}}><Smartphone size={16} color="var(--accent-hover)"/><span style={{fontWeight:600,fontSize:14}}>IoT 슬림 스틱 연동</span></div>
              <div style={{fontSize:12,color:'var(--text-secondary)',padding:'10px 14px',background:'var(--bg-hover)',borderRadius:'var(--radius-md)'}}>시리얼 번호는 스틱 하단 스티커에서 확인. 나중에 연동하려면 비워두세요.</div>
              <div><label className="label">디바이스 시리얼 번호</label><input className="input" placeholder="OG-STICK-XXXXXX" value={form.device_serial} onChange={e=>set('device_serial',e.target.value.toUpperCase())} style={{fontFamily:'var(--font-mono)',letterSpacing:'0.05em'}}/></div>
              <div><label className="label">설치 위치</label><select className="input" value={form.device_location} onChange={e=>set('device_location',e.target.value)}>{['거실','침실','주방','욕실','현관'].map(l=><option key={l}>{l}</option>)}</select></div>
            </div>
          )}

          {error&&<div style={{marginTop:14,padding:'10px 14px',background:'var(--risk-red-bg)',borderRadius:'var(--radius-md)',color:'var(--risk-red)',fontSize:13}}>{error}</div>}
        </div>

        <div className="modal-footer">
          {step>1&&<button className="btn btn-secondary" onClick={()=>setStep(s=>s-1)}>이전</button>}
          <button className="btn btn-secondary" onClick={onClose}>취소</button>
          {step<3?<button className="btn btn-primary" onClick={()=>setStep(s=>s+1)}>다음</button>
          :<button className="btn btn-primary" onClick={handleSubmit} disabled={loading}>{loading?<><div className="spinner" style={{width:14,height:14}}/>등록 중...</>:'등록 완료'}</button>}
        </div>
      </div>
    </div>
  );
}
