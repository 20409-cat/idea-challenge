import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import useAuthStore from '../../hooks/useAuthStore';
import { LayoutDashboard, Users, Bell, Shield, LogOut, Activity, ChevronRight } from 'lucide-react';

const ROLE_LABELS = { super_admin:'슈퍼관리자', local_gov:'지자체 담당자', welfare_worker:'복지 담당사' };
const navItems = [
  { to:'/dashboard', icon:LayoutDashboard, label:'종합 관제',   desc:'실시간 현황' },
  { to:'/members',   icon:Users,           label:'수혜자 관리', desc:'독거 가구' },
  { to:'/alerts',    icon:Bell,            label:'알림·장애',   desc:'긴급 상황' },
  { to:'/admin',     icon:Shield,          label:'권한 관리',   desc:'계정·승인', roles:['super_admin','local_gov'] },
];

export default function Sidebar() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const handleLogout = async () => { await logout(); navigate('/login'); };

  return (
    <aside className="sidebar">
      {/* 로고 */}
      <div style={{padding:'18px 16px 14px',borderBottom:'1px solid var(--border)'}}>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:32,height:32,borderRadius:8,background:'#2563eb',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
            <Activity size={17} color="#fff"/>
          </div>
          <div>
            <div style={{fontSize:15,fontWeight:800,color:'var(--text-primary)',letterSpacing:'-0.02em'}}>온결</div>
            <div style={{fontSize:9,color:'var(--text-muted)',letterSpacing:'0.06em'}}>ADMIN SYSTEM</div>
          </div>
        </div>
      </div>

      {/* 네비게이션 */}
      <nav style={{flex:1,padding:'10px 8px'}}>
        <div style={{fontSize:10,fontWeight:700,color:'var(--text-muted)',padding:'8px 8px 4px',letterSpacing:'0.08em'}}>메뉴</div>
        {navItems.filter(i=>!i.roles||i.roles.includes(user?.role)).map(({to,icon:Icon,label,desc})=>(
          <NavLink key={to} to={to} style={({isActive})=>({
            display:'flex',alignItems:'center',gap:9,padding:'8px 10px',
            borderRadius:'var(--radius-md)',marginBottom:2,textDecoration:'none',transition:'all .15s',
            background:isActive?'var(--accent-bg)':'transparent',
            color:isActive?'var(--accent)':'var(--text-secondary)',
            borderLeft:isActive?'2px solid var(--accent)':'2px solid transparent',
          })}>
            <Icon size={15}/>
            <div style={{flex:1}}>
              <div style={{fontSize:13,fontWeight:600}}>{label}</div>
              <div style={{fontSize:10,opacity:.7}}>{desc}</div>
            </div>
            <ChevronRight size={11} style={{opacity:.35}}/>
          </NavLink>
        ))}
      </nav>

      {/* 사용자 */}
      <div style={{padding:'12px',borderTop:'1px solid var(--border)'}}>
        <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:10}}>
          <div style={{width:32,height:32,borderRadius:'50%',background:'var(--accent-bg)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,fontWeight:700,color:'var(--accent)',border:'1px solid var(--accent-border)',flexShrink:0}}>
            {user?.name?.[0]||'?'}
          </div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:13,fontWeight:600,color:'var(--text-primary)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{user?.name}</div>
            <div style={{fontSize:11,color:'var(--text-muted)'}}>{ROLE_LABELS[user?.role]}</div>
          </div>
        </div>
        <button onClick={handleLogout} className="btn btn-secondary" style={{width:'100%',justifyContent:'center',fontSize:12}}>
          <LogOut size={13}/> 로그아웃
        </button>
      </div>
    </aside>
  );
}
