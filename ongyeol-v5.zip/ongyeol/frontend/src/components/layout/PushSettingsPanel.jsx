import React from 'react';
import { Bell, BellOff, BellRing, Smartphone } from 'lucide-react';
import usePushNotification from '../../hooks/usePushNotification';

export default function PushSettingsPanel() {
  const { supported, permission, subscribed, loading, subscribe, unsubscribe, sendTest } = usePushNotification();

  if (!supported) return (
    <div style={{ padding:'12px 14px', background:'#fef9c3', border:'1px solid #fde68a', borderRadius:8, fontSize:13, color:'#78350f' }}>
      이 브라우저는 웹 푸시 알림을 지원하지 않습니다. Chrome 또는 Edge를 사용하세요.
    </div>
  );

  return (
    <div className="card" style={{ padding:20 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:16 }}>
        <div style={{ width:36, height:36, borderRadius:9, background:'#eff6ff', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <Smartphone size={18} color="#2563eb" />
        </div>
        <div>
          <div style={{ fontSize:14, fontWeight:700, color:'#111' }}>휴대폰 푸시 알림</div>
          <div style={{ fontSize:12, color:'#6b7280' }}>긴급 위급상황 발생 시 즉시 알림</div>
        </div>
        {/* 상태 배지 */}
        <div style={{ marginLeft:'auto' }}>
          {subscribed
            ? <span className="badge badge-green">활성화</span>
            : <span className="badge badge-red">비활성화</span>
          }
        </div>
      </div>

      {/* 권한 거부 안내 */}
      {permission === 'denied' && (
        <div style={{ padding:'10px 13px', background:'#fef2f2', border:'1px solid #fecaca', borderRadius:8, fontSize:12, color:'#b91c1c', marginBottom:14 }}>
          브라우저에서 알림이 차단됐습니다. 브라우저 주소창 왼쪽의 🔒 아이콘 → 알림 → 허용으로 변경하세요.
        </div>
      )}

      {/* 설명 */}
      {!subscribed && permission !== 'denied' && (
        <div style={{ fontSize:13, color:'#6b7280', marginBottom:14, lineHeight:1.6 }}>
          활성화하면 긴급 위급상황, 배터리 부족 등의 알림을 이 기기로 바로 받을 수 있습니다.
        </div>
      )}

      {subscribed && (
        <div style={{ fontSize:13, color:'#6b7280', marginBottom:14, lineHeight:1.6 }}>
          긴급 알림 발생 시 이 기기로 즉시 푸시 알림이 전송됩니다.
        </div>
      )}

      {/* 버튼들 */}
      <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
        {!subscribed ? (
          <button
            className="btn btn-primary"
            onClick={subscribe}
            disabled={loading || permission === 'denied'}
          >
            <Bell size={14} />
            {loading ? '처리 중...' : '알림 활성화'}
          </button>
        ) : (
          <>
            <button className="btn btn-secondary" onClick={sendTest}>
              <BellRing size={14} />
              테스트 알림 전송
            </button>
            <button className="btn btn-danger" onClick={unsubscribe} disabled={loading}>
              <BellOff size={14} />
              {loading ? '처리 중...' : '알림 비활성화'}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
