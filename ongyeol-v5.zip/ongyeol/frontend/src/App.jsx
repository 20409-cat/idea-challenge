import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import useAuthStore from './hooks/useAuthStore';
import Sidebar from './components/layout/Sidebar';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import MembersPage from './pages/MembersPage';
import AlertsPage from './pages/AlertsPage';
import AdminPage from './pages/AdminPage';
import './styles/global.css';

function ProtectedRoute({ children, roles }) {
  const { user } = useAuthStore();
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/dashboard" replace />;
  return (
    <div className="app-layout">
      <Sidebar />
      <main className="main-content">{children}</main>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-right" toastOptions={{
        style:{ background:'#fff', color:'#0f172a', border:'1px solid #e2e8f0', fontSize:13, boxShadow:'0 4px 12px rgba(0,0,0,.1)' },
        success:{ iconTheme:{ primary:'#16a34a', secondary:'#fff' } },
        error:  { iconTheme:{ primary:'#dc2626', secondary:'#fff' } },
      }}/>
      <Routes>
        <Route path="/login"    element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
        <Route path="/members"   element={<ProtectedRoute><MembersPage /></ProtectedRoute>} />
        <Route path="/alerts"    element={<ProtectedRoute><AlertsPage /></ProtectedRoute>} />
        <Route path="/admin"     element={<ProtectedRoute roles={['super_admin','local_gov']}><AdminPage /></ProtectedRoute>} />
        <Route path="*"          element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
