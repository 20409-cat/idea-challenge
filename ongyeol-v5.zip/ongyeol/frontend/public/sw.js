// ============================================
// 온결 관리자 시스템 — Service Worker
// 웹 푸시 알림 수신 및 클릭 처리
// ============================================

self.addEventListener('push', function(event) {
  if (!event.data) return;

  const data = event.data.json();

  const options = {
    body:    data.body  || '새 알림이 있습니다.',
    icon:    data.icon  || '/icon-192.png',
    badge:   data.badge || '/badge-72.png',
    tag:     data.tag   || 'ongyeol-notification',
    vibrate: [200, 100, 200],
    data:    { url: data.url || '/' },
    actions: [
      { action: 'open',    title: '바로 확인' },
      { action: 'dismiss', title: '닫기' },
    ],
    requireInteraction: data.tag === 'ongyeol-critical',
  };

  event.waitUntil(
    self.registration.showNotification(data.title || '온결 알림', options)
  );
});

self.addEventListener('notificationclick', function(event) {
  event.notification.close();

  if (event.action === 'dismiss') return;

  const url = event.notification.data?.url || '/alerts';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(clientList) {
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          client.navigate(url);
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(url);
      }
    })
  );
});

self.addEventListener('install',  () => self.skipWaiting());
self.addEventListener('activate', () => clients.claim());
