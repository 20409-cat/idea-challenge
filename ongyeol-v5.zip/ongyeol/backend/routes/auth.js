const express = require('express');
const router  = express.Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const pool    = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const { sendApprovalEmail } = require('../utils/mailer');

// POST /api/auth/request-account — 계정 신청 (비로그인, 관리자 승인 필요)
router.post('/request-account', async (req, res) => {
  try {
    const { email, password, name, department, phone } = req.body;
    if (!email || !password || !name) {
      return res.status(400).json({ error: '이름, 이메일, 비밀번호는 필수입니다.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: '비밀번호는 8자 이상이어야 합니다.' });
    }

    // 이미 존재하는 이메일 확인
    const [existing] = await pool.query(
      'SELECT id FROM admins WHERE email = ?', [email.toLowerCase().trim()]
    );
    if (existing.length > 0) {
      return res.status(409).json({ error: '이미 사용 중인 이메일입니다.' });
    }

    const hash = await bcrypt.hash(password, 12);

    // is_active = 0 으로 저장 → 관리자가 승인해야 로그인 가능
    await pool.query(
      `INSERT INTO admins (id, email, password_hash, name, role, department, phone, is_active)
       VALUES (UUID(), ?, ?, ?, 'welfare_worker', ?, ?, 0)`,
      [email.toLowerCase().trim(), hash, name, department || '', phone || '']
    );

    res.status(201).json({
      message: '계정 신청이 완료됐습니다. 관리자 승인 후 로그인할 수 있습니다.',
    });
  } catch (err) {
    console.error('계정 신청 오류:', err);
    res.status(500).json({ error: '계정 신청에 실패했습니다.' });
  }
});

// GET /api/auth/pending — 승인 대기 계정 목록 (슈퍼관리자 전용)
router.get('/pending', authMiddleware, async (req, res) => {
  if (!['super_admin', 'local_gov'].includes(req.user.role)) {
    return res.status(403).json({ error: '권한이 없습니다.' });
  }
  const [rows] = await pool.query(
    `SELECT id, email, name, department, phone, created_at
     FROM admins WHERE is_active = 0 ORDER BY created_at DESC`
  );
  res.json(rows);
});

// PATCH /api/auth/approve/:id — 계정 승인 (슈퍼관리자 전용)
router.patch('/approve/:id', authMiddleware, async (req, res) => {
  if (!['super_admin', 'local_gov'].includes(req.user.role)) {
    return res.status(403).json({ error: '권한이 없습니다.' });
  }
  try {
    const { role, approved } = req.body;
    const finalRole = role || 'welfare_worker';

    if (approved === false) {
      // 거절 → 계정 삭제
      const [[target]] = await pool.query('SELECT email, name FROM admins WHERE id = ?', [req.params.id]);
      await pool.query('DELETE FROM admins WHERE id = ?', [req.params.id]);
      // 거절 이메일 발송
      if (target) {
        await sendApprovalEmail({ toEmail: target.email, toName: target.name, approved: false });
      }
      return res.json({ message: '계정 신청이 거절됐습니다.' });
    }

    // 승인
    const [[target]] = await pool.query('SELECT email, name FROM admins WHERE id = ?', [req.params.id]);
    await pool.query(
      'UPDATE admins SET is_active = 1, role = ? WHERE id = ?',
      [finalRole, req.params.id]
    );
    // 승인 이메일 발송
    if (target) {
      await sendApprovalEmail({ toEmail: target.email, toName: target.name, approved: true, role: finalRole });
    }
    res.json({ message: '계정이 승인됐습니다.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: '승인 처리 실패' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: '이메일과 비밀번호를 입력하세요.' });

    const [rows] = await pool.query(
      'SELECT * FROM admins WHERE email = ? AND is_active = 1', [email.toLowerCase().trim()]
    );
    if (!rows.length)
      return res.status(401).json({ error: '이메일 또는 비밀번호가 올바르지 않습니다.' });

    const admin = rows[0];
    const valid = await bcrypt.compare(password, admin.password_hash);
    if (!valid)
      return res.status(401).json({ error: '이메일 또는 비밀번호가 올바르지 않습니다.' });

    await pool.query('UPDATE admins SET last_login = NOW() WHERE id = ?', [admin.id]);

    const token = jwt.sign(
      { id: admin.id, email: admin.email, role: admin.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
    );

    res.json({
      token,
      user: { id: admin.id, email: admin.email, name: admin.name, role: admin.role, department: admin.department },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: '서버 오류' });
  }
});

// GET /api/auth/me
router.get('/me', authMiddleware, (req, res) => res.json({ user: req.user }));

// POST /api/auth/logout
router.post('/logout', authMiddleware, (req, res) => res.json({ message: '로그아웃 되었습니다.' }));

// GET /api/auth/admins
router.get('/admins', authMiddleware, async (req, res) => {
  if (!['super_admin','local_gov'].includes(req.user.role))
    return res.status(403).json({ error: '권한 없음' });
  const [rows] = await pool.query(
    'SELECT id, email, name, role, department, phone, is_active, last_login, created_at FROM admins ORDER BY created_at DESC'
  );
  res.json(rows);
});

// POST /api/auth/register
router.post('/register', authMiddleware, async (req, res) => {
  if (req.user.role !== 'super_admin')
    return res.status(403).json({ error: '슈퍼관리자만 계정을 생성할 수 있습니다.' });
  try {
    const { email, password, name, role, department, phone } = req.body;
    if (!email || !password || !name || !role)
      return res.status(400).json({ error: '필수 항목을 입력하세요.' });

    const hash = await bcrypt.hash(password, 12);
    await pool.query(
      'INSERT INTO admins (id, email, password_hash, name, role, department, phone) VALUES (UUID(),?,?,?,?,?,?)',
      [email.toLowerCase(), hash, name, role, department, phone]
    );
    res.status(201).json({ message: '계정이 생성되었습니다.' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ error: '이미 존재하는 이메일입니다.' });
    res.status(500).json({ error: '계정 생성 실패' });
  }
});

// PATCH /api/auth/admins/:id/deactivate
router.patch('/admins/:id/deactivate', authMiddleware, async (req, res) => {
  if (!['super_admin', 'local_gov'].includes(req.user.role)) {
    return res.status(403).json({ error: '권한이 없습니다.' });
  }
  try {
    await pool.query('UPDATE admins SET is_active = 0 WHERE id = ? AND role != ?', [req.params.id, 'super_admin']);
    res.json({ message: '비활성화됐습니다.' });
  } catch (err) {
    res.status(500).json({ error: '처리 실패' });
  }
});

module.exports = router;
