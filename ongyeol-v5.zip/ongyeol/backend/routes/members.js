const express = require('express');
const router = express.Router();
const pool   = require('../config/database');
const { authMiddleware } = require('../middleware/auth');

router.use(authMiddleware);

// GET /api/members
router.get('/', async (req, res) => {
  try {
    const { risk_level, district, search, page = 1, limit = 25 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const where  = ['m.is_active = 1'];
    const params = [];

    if (risk_level) { where.push('m.risk_level = ?');  params.push(risk_level); }
    if (district)   { where.push('m.district = ?');    params.push(district); }
    if (search)     { where.push('(m.name LIKE ? OR m.address LIKE ?)'); params.push(`%${search}%`, `%${search}%`); }

    const whereSQL = `WHERE ${where.join(' AND ')}`;

    const [data] = await pool.query(`
      SELECT
        m.id, m.name, m.birth_date, m.gender, m.address, m.district,
        m.phone, m.risk_level, m.registered_at,
        m.emergency_contact_name, m.emergency_contact_phone,
        a.name AS welfare_worker_name,
        d.device_serial, d.is_online AS device_online, d.battery_level,
        wr.overall_score
      FROM members m
      LEFT JOIN admins a            ON a.id = m.assigned_welfare_worker_id
      LEFT JOIN devices d           ON d.member_id = m.id
      LEFT JOIN wellness_reports wr ON wr.member_id = m.id AND wr.report_date = CURDATE()
      ${whereSQL}
      ORDER BY FIELD(m.risk_level,'red','yellow','green'), m.name
      LIMIT ? OFFSET ?
    `, [...params, parseInt(limit), offset]);

    const [[{ total }]] = await pool.query(
      `SELECT COUNT(*) AS total FROM members m ${whereSQL}`, params
    );

    res.json({ data, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: '목록 조회 실패' });
  }
});

// GET /api/members/:id
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const [[member]] = await pool.query(`
      SELECT m.*, a.name AS welfare_worker_name, a.phone AS welfare_worker_phone
      FROM members m
      LEFT JOIN admins a ON a.id = m.assigned_welfare_worker_id
      WHERE m.id = ?
    `, [id]);

    if (!member) return res.status(404).json({ error: '수혜자를 찾을 수 없습니다.' });

    const [device]   = await pool.query('SELECT * FROM devices WHERE member_id = ? LIMIT 1', [id]);
    const [reports]  = await pool.query('SELECT * FROM wellness_reports WHERE member_id = ? ORDER BY report_date DESC LIMIT 7', [id]);
    const [alerts]   = await pool.query('SELECT * FROM alerts WHERE member_id = ? ORDER BY created_at DESC LIMIT 10', [id]);

    res.json({ member, device: device[0] || null, wellnessReports: reports, recentAlerts: alerts });
  } catch (err) {
    res.status(500).json({ error: '상세 조회 실패' });
  }
});

// POST /api/members
router.post('/', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const {
      name, birth_date, gender, address, district, phone, medical_notes,
      emergency_contact_name, emergency_contact_phone, emergency_contact_email,
      emergency_contact_relation, assigned_welfare_worker_id, device_serial, device_location,
    } = req.body;

    if (!name || !birth_date || !address || !district)
      return res.status(400).json({ error: '필수 항목을 입력하세요.' });

    const memberId = require('uuid').v4();
    await conn.query(
      `INSERT INTO members
        (id,name,birth_date,gender,address,district,phone,medical_notes,
         emergency_contact_name,emergency_contact_phone,emergency_contact_email,
         emergency_contact_relation,assigned_welfare_worker_id)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [memberId, name, birth_date, gender, address, district, phone, medical_notes,
       emergency_contact_name, emergency_contact_phone, emergency_contact_email || null,
       emergency_contact_relation, assigned_welfare_worker_id || null]
    );

    if (device_serial) {
      await conn.query(
        'INSERT INTO devices (id,device_serial,member_id,battery_level,location_in_home,firmware_version) VALUES (UUID(),?,?,100,?,?)',
        [device_serial, memberId, device_location || '거실', '1.0.0']
      );
    }

    await conn.commit();
    res.status(201).json({ id: memberId, message: '등록 완료' });
  } catch (err) {
    await conn.rollback();
    if (err.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ error: '이미 등록된 디바이스 시리얼입니다.' });
    res.status(500).json({ error: '등록 실패' });
  } finally {
    conn.release();
  }
});

// PATCH /api/members/:id
router.patch('/:id', async (req, res) => {
  try {
    const allowed = ['name','birth_date','gender','address','district','phone',
      'medical_notes','emergency_contact_name','emergency_contact_phone',
      'emergency_contact_relation','assigned_welfare_worker_id','risk_level'];
    const sets = [], vals = [];
    for (const f of allowed) {
      if (req.body[f] !== undefined) { sets.push(`${f} = ?`); vals.push(req.body[f]); }
    }
    if (!sets.length) return res.status(400).json({ error: '수정할 항목이 없습니다.' });
    vals.push(req.params.id);
    await pool.query(`UPDATE members SET ${sets.join(', ')} WHERE id = ?`, vals);
    res.json({ message: '수정되었습니다.' });
  } catch (err) {
    res.status(500).json({ error: '수정 실패' });
  }
});

// DELETE /api/members/:id
router.delete('/:id', async (req, res) => {
  try {
    await pool.query('UPDATE members SET is_active = 0 WHERE id = ?', [req.params.id]);
    res.json({ message: '비활성화되었습니다.' });
  } catch (err) {
    res.status(500).json({ error: '처리 실패' });
  }
});

// GET /api/members/:id/wellness
router.get('/:id/wellness', async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT * FROM wellness_reports WHERE member_id = ? ORDER BY report_date DESC LIMIT 30',
      [req.params.id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: '웰니스 조회 실패' });
  }
});

module.exports = router;
