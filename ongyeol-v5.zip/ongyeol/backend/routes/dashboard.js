const express = require('express');
const router = express.Router();
const pool   = require('../config/database');
const { authMiddleware } = require('../middleware/auth');

router.use(authMiddleware);

// GET /api/dashboard/summary
router.get('/summary', async (req, res) => {
  try {
    const [[memberStats]] = await pool.query(`
      SELECT
        COUNT(*)                                   AS total,
        SUM(risk_level = 'red')                    AS red_count,
        SUM(risk_level = 'yellow')                 AS yellow_count,
        SUM(risk_level = 'green')                  AS green_count
      FROM members WHERE is_active = 1
    `);

    const [[deviceStats]] = await pool.query(`
      SELECT
        COUNT(*)                   AS total,
        SUM(is_online = 1)         AS online,
        SUM(battery_level < 20)    AS low_battery
      FROM devices
    `);

    const [[alertStats]] = await pool.query(`
      SELECT
        SUM(is_resolved = 0)                        AS unresolved,
        SUM(is_resolved = 0 AND severity='critical') AS critical,
        SUM(is_resolved = 0 AND severity='warning')  AS warning
      FROM alerts
    `);

    const [riskByDistrict] = await pool.query(`
      SELECT district, risk_level, COUNT(*) AS count
      FROM members WHERE is_active = 1
      GROUP BY district, risk_level ORDER BY district
    `);

    res.json({
      members: memberStats,
      devices: deviceStats,
      alerts:  alertStats,
      riskByDistrict,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: '데이터 조회 실패' });
  }
});

// GET /api/dashboard/members-map
router.get('/members-map', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        m.id, m.name, m.risk_level, m.district, m.address,
        d.is_online AS device_online, d.battery_level,
        d.last_ping, d.device_serial,
        wr.overall_score
      FROM members m
      LEFT JOIN devices d          ON d.member_id = m.id
      LEFT JOIN wellness_reports wr ON wr.member_id = m.id AND wr.report_date = CURDATE()
      WHERE m.is_active = 1
      ORDER BY FIELD(m.risk_level,'red','yellow','green')
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: '지도 데이터 오류' });
  }
});

// GET /api/dashboard/recent-alerts
router.get('/recent-alerts', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT a.id, a.alert_type, a.severity, a.message, a.is_resolved, a.created_at,
             m.name AS member_name, m.district, m.risk_level
      FROM alerts a
      JOIN members m ON m.id = a.member_id
      ORDER BY a.created_at DESC
      LIMIT 20
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: '알림 조회 오류' });
  }
});

module.exports = router;
