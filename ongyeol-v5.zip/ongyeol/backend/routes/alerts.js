const express = require('express');
const router = express.Router();
const pool   = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const { sendPushToAll } = require('./push');
const { sendAlertEmail, sendGuardianEmail } = require('../utils/mailer');

router.use(authMiddleware);

// POST /api/alerts — 새 알림 생성 + 긴급이면 푸시 발송
router.post('/', async (req, res) => {
  try {
    const { member_id, alert_type, severity, message } = req.body;
    if (!member_id || !alert_type || !severity || !message)
      return res.status(400).json({ error: '필수 항목 누락' });

    const [[member]] = await pool.query(
      'SELECT name, district FROM members WHERE id = ?', [member_id]
    );
    if (!member) return res.status(404).json({ error: '수혜자 없음' });

    await pool.query(
      'INSERT INTO alerts (id, member_id, alert_type, severity, message) VALUES (UUID(),?,?,?,?)',
      [member_id, alert_type, severity, message]
    );

    if (severity === 'critical') {
      try {
        await sendPushToAll({
          title: `🚨 긴급 — ${member.name}님 (${member.district})`,
          body:  message,
          icon:  '/icon-192.png',
          badge: '/badge-72.png',
          tag:   'ongyeol-critical',
          url:   '/alerts',
        });
      } catch (e) { console.warn('푸시 전송 실패 (알림은 저장됨):', e.message); }

      // 1. 전체 관리자에게 이메일
      try {
        const [admins] = await pool.query(
          'SELECT email, name FROM admins WHERE is_active = 1'
        );
        for (const admin of admins) {
          await sendAlertEmail({
            toEmail: admin.email, toName: admin.name,
            memberName: member.name, district: member.district,
            alertType: alert_type, message,
          });
        }
      } catch (e) { console.warn('관리자 이메일 발송 실패:', e.message); }

      // 2. 보호자에게 이메일 (emergency_contact_email 있을 경우)
      try {
        const [[memberFull]] = await pool.query(
          `SELECT emergency_contact_name, emergency_contact_email,
                  emergency_contact_phone, emergency_contact_relation
           FROM members WHERE id = ?`, [member_id]
        );
        if (memberFull?.emergency_contact_email) {
          await sendGuardianEmail({
            toEmail:      memberFull.emergency_contact_email,
            toName:       memberFull.emergency_contact_name,
            relation:     memberFull.emergency_contact_relation,
            memberName:   member.name,
            district:     member.district,
            alertType:    alert_type,
            message,
          });
        }
      } catch (e) { console.warn('보호자 이메일 발송 실패:', e.message); }
    }
    res.status(201).json({ message: '알림 생성 완료' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: '알림 생성 실패' });
  }
});

// GET /api/alerts
router.get('/', async (req, res) => {
  try {
    const { severity, is_resolved } = req.query;
    const where = [], params = [];
    if (severity)            { where.push('a.severity = ?');     params.push(severity); }
    if (is_resolved !== undefined) { where.push('a.is_resolved = ?'); params.push(is_resolved === 'true' ? 1 : 0); }

    const whereSQL = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const [rows] = await pool.query(`
      SELECT a.*, m.name AS member_name, m.district, m.phone AS member_phone, m.risk_level,
             adm.name AS resolved_by_name, d.device_serial, d.battery_level
      FROM alerts a
      JOIN members m            ON m.id = a.member_id
      LEFT JOIN admins adm      ON adm.id = a.resolved_by
      LEFT JOIN devices d       ON d.id = a.device_id
      ${whereSQL}
      ORDER BY FIELD(a.severity,'critical','warning','info'), a.created_at DESC
      LIMIT 50
    `, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: '알림 조회 실패' });
  }
});

// PATCH /api/alerts/:id/resolve
router.patch('/:id/resolve', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { resolution_note, action_taken, contacted_emergency, visit_required, outcome } = req.body;

    const [[alert]] = await conn.query(
      'SELECT * FROM alerts WHERE id = ? AND is_resolved = 0', [req.params.id]
    );
    if (!alert) {
      await conn.rollback();
      return res.status(404).json({ error: '알림을 찾을 수 없거나 이미 처리되었습니다.' });
    }

    await conn.query(
      `UPDATE alerts SET is_resolved=1, resolved_by=?, resolved_at=NOW(), resolution_note=? WHERE id=?`,
      [req.user.id, resolution_note || '', req.params.id]
    );

    await conn.query(
      `INSERT INTO incident_logs
        (id,alert_id,member_id,handled_by,action_taken,contacted_emergency,visit_required,outcome)
       VALUES (UUID(),?,?,?,?,?,?,?)`,
      [req.params.id, alert.member_id, req.user.id,
       action_taken || '알림 확인 및 처리 완료',
       contacted_emergency ? 1 : 0,
       visit_required ? 1 : 0,
       outcome || '정상 처리']
    );

    await conn.commit();
    res.json({ message: '처리되었습니다.' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ error: '처리 실패' });
  } finally {
    conn.release();
  }
});

// GET /api/alerts/incident-logs
router.get('/incident-logs', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT il.*, m.name AS member_name, m.district,
             adm.name AS handler_name,
             a.alert_type, a.severity, a.message AS alert_message
      FROM incident_logs il
      JOIN members m         ON m.id = il.member_id
      LEFT JOIN admins adm   ON adm.id = il.handled_by
      LEFT JOIN alerts a     ON a.id = il.alert_id
      ORDER BY il.logged_at DESC
      LIMIT 50
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: '조치 일지 조회 실패' });
  }
});

// GET /api/alerts/devices
router.get('/devices', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT d.*, m.name AS member_name, m.district, m.risk_level
      FROM devices d
      LEFT JOIN members m ON m.id = d.member_id
      ORDER BY d.battery_level ASC, d.is_online ASC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: '디바이스 조회 실패' });
  }
});

module.exports = router;
