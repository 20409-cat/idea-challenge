const express  = require('express');
const router   = express.Router();
const pool     = require('../config/database');
const { authMiddleware } = require('../middleware/auth');
const webpush  = require('web-push');
require('dotenv').config();

// VAPID 키 설정 (서버 시작 시 .env에서 읽음)
webpush.setVapidDetails(
  'mailto:' + (process.env.ADMIN_EMAIL || 'admin@ongyeol.go.kr'),
  process.env.VAPID_PUBLIC_KEY,
  process.env.VAPID_PRIVATE_KEY
);

// POST /api/push/subscribe — 브라우저 구독 정보 저장
router.post('/subscribe', authMiddleware, async (req, res) => {
  try {
    const { subscription } = req.body;
    if (!subscription?.endpoint) {
      return res.status(400).json({ error: '구독 정보가 없습니다.' });
    }

    const subStr = JSON.stringify(subscription);

    // 이미 존재하면 UPDATE, 없으면 INSERT
    await pool.query(
      `INSERT INTO push_subscriptions (admin_id, subscription, updated_at)
       VALUES (?, ?, NOW())
       ON DUPLICATE KEY UPDATE subscription = VALUES(subscription), updated_at = NOW()`,
      [req.user.id, subStr]
    );

    res.json({ message: '푸시 알림 구독 완료' });
  } catch (err) {
    console.error('구독 저장 오류:', err);
    res.status(500).json({ error: '구독 저장 실패' });
  }
});

// DELETE /api/push/unsubscribe — 구독 해제
router.delete('/unsubscribe', authMiddleware, async (req, res) => {
  try {
    await pool.query(
      'DELETE FROM push_subscriptions WHERE admin_id = ?',
      [req.user.id]
    );
    res.json({ message: '푸시 알림 구독 해제 완료' });
  } catch (err) {
    res.status(500).json({ error: '구독 해제 실패' });
  }
});

// POST /api/push/send-test — 테스트 알림 전송
router.post('/send-test', authMiddleware, async (req, res) => {
  try {
    await sendPushToUser(req.user.id, {
      title: '온결 테스트 알림',
      body:  '푸시 알림이 정상 작동합니다.',
      icon:  '/icon-192.png',
      badge: '/badge-72.png',
      url:   '/alerts',
    });
    res.json({ message: '테스트 알림 전송 완료' });
  } catch (err) {
    res.status(500).json({ error: '알림 전송 실패: ' + err.message });
  }
});

// ── 내부 유틸: 특정 관리자에게 푸시 ──
async function sendPushToUser(adminId, payload) {
  const [rows] = await pool.query(
    'SELECT subscription FROM push_subscriptions WHERE admin_id = ?',
    [adminId]
  );
  if (!rows.length) return;

  const sub = JSON.parse(rows[0].subscription);
  await webpush.sendNotification(sub, JSON.stringify(payload));
}

// ── 내부 유틸: 전체 구독자에게 긴급 알림 ──
async function sendPushToAll(payload) {
  const [rows] = await pool.query('SELECT admin_id, subscription FROM push_subscriptions');
  const results = await Promise.allSettled(
    rows.map(r => webpush.sendNotification(JSON.parse(r.subscription), JSON.stringify(payload)))
  );
  // 만료된 구독 삭제
  for (let i = 0; i < rows.length; i++) {
    if (results[i].status === 'rejected') {
      const statusCode = results[i].reason?.statusCode;
      if (statusCode === 404 || statusCode === 410) {
        await pool.query(
          'DELETE FROM push_subscriptions WHERE admin_id = ?',
          [rows[i].admin_id]
        );
      }
    }
  }
}

module.exports = { router, sendPushToUser, sendPushToAll };
