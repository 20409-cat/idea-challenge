const nodemailer = require('nodemailer');
require('dotenv').config();

// 메일 전송기 (Gmail SMTP)
const transporter = nodemailer.createTransport({
  host:   process.env.MAIL_HOST || 'smtp.gmail.com',
  port:   parseInt(process.env.MAIL_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.MAIL_USER,
    pass: process.env.MAIL_PASS,
  },
});

// ── 긴급 알림 이메일 ──
async function sendAlertEmail({ toEmail, toName, memberName, district, alertType, message }) {
  if (!process.env.MAIL_USER || !process.env.MAIL_PASS) {
    console.log('📧 이메일 설정 없음 — 전송 건너뜀');
    return;
  }

  const ALERT_LABELS = {
    no_movement:      '움직임 미감지',
    fall_detected:    '낙상 감지',
    sos:              'SOS 호출',
    low_battery:      '배터리 부족',
    offline:          '기기 오프라인',
    abnormal_pattern: '이상 패턴 감지',
  };

  const subject = `[온결 긴급] ${memberName}님 — ${ALERT_LABELS[alertType] || alertType}`;

  const html = `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto">
      <div style="background:#dc2626;padding:16px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0;font-size:18px">🚨 긴급 위급상황 알림</h2>
      </div>
      <div style="background:#fff;border:1px solid #e5e7eb;border-top:none;padding:24px;border-radius:0 0 8px 8px">
        <p style="color:#374151;margin:0 0 16px">안녕하세요, <strong>${toName}</strong>님.</p>
        <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:16px;margin-bottom:20px">
          <table style="width:100%;border-collapse:collapse">
            <tr><td style="color:#6b7280;padding:4px 0;width:90px">수혜자</td><td style="font-weight:700;color:#111">${memberName}</td></tr>
            <tr><td style="color:#6b7280;padding:4px 0">구역</td><td style="color:#374151">${district}</td></tr>
            <tr><td style="color:#6b7280;padding:4px 0">유형</td><td style="color:#b91c1c;font-weight:600">${ALERT_LABELS[alertType] || alertType}</td></tr>
            <tr><td style="color:#6b7280;padding:4px 0">내용</td><td style="color:#374151">${message}</td></tr>
          </table>
        </div>
        <a href="http://localhost:3000/alerts" style="display:inline-block;background:#dc2626;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;font-weight:600">알림 확인하기</a>
        <p style="color:#9ca3af;font-size:12px;margin-top:20px">온결 관리자 시스템 · 이 메일은 자동 발송됩니다</p>
      </div>
    </div>
  `;

  try {
    await transporter.sendMail({
      from:    process.env.MAIL_FROM || process.env.MAIL_USER,
      to:      toEmail,
      subject,
      html,
    });
    console.log(`📧 이메일 발송 완료 → ${toEmail}`);
  } catch (err) {
    console.warn(`📧 이메일 발송 실패 (${toEmail}):`, err.message);
  }
}

// ── 회원가입 승인 이메일 ──
async function sendApprovalEmail({ toEmail, toName, approved, role }) {
  if (!process.env.MAIL_USER || !process.env.MAIL_PASS) return;

  const ROLE_LABELS = {
    super_admin:    '슈퍼관리자',
    local_gov:      '지자체 담당자',
    welfare_worker: '복지 담당사',
  };

  const subject = approved
    ? '[온결] 계정이 승인됐습니다'
    : '[온결] 계정 신청이 반려됐습니다';

  const html = approved ? `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto">
      <div style="background:#16a34a;padding:16px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0">✅ 계정 승인 완료</h2>
      </div>
      <div style="background:#fff;border:1px solid #e5e7eb;border-top:none;padding:24px;border-radius:0 0 8px 8px">
        <p style="color:#374151"><strong>${toName}</strong>님, 온결 관리자 시스템 계정이 승인됐습니다.</p>
        <p style="color:#374151">부여된 역할: <strong>${ROLE_LABELS[role] || role}</strong></p>
        <a href="http://localhost:3000/login" style="display:inline-block;background:#2563eb;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;font-weight:600;margin-top:8px">로그인하기</a>
        <p style="color:#9ca3af;font-size:12px;margin-top:20px">온결 관리자 시스템</p>
      </div>
    </div>
  ` : `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto">
      <div style="background:#6b7280;padding:16px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0">계정 신청 반려</h2>
      </div>
      <div style="background:#fff;border:1px solid #e5e7eb;border-top:none;padding:24px;border-radius:0 0 8px 8px">
        <p style="color:#374151"><strong>${toName}</strong>님, 아쉽게도 계정 신청이 반려됐습니다.</p>
        <p style="color:#6b7280">문의사항은 시스템 관리자에게 연락해주세요.</p>
      </div>
    </div>
  `;

  try {
    await transporter.sendMail({
      from: process.env.MAIL_FROM || process.env.MAIL_USER,
      to: toEmail,
      subject,
      html,
    });
    console.log(`📧 승인 이메일 발송 → ${toEmail}`);
  } catch (err) {
    console.warn('📧 승인 이메일 발송 실패:', err.message);
  }
}

// ── 미처리 알림 에스컬레이션 이메일 ──
async function sendEscalationEmail({ toEmail, toName, memberName, district, message, hoursUnresolved }) {
  if (!process.env.MAIL_USER || !process.env.MAIL_PASS) return;

  const html = `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto">
      <div style="background:#d97706;padding:16px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0">⚠️ 미처리 알림 에스컬레이션</h2>
      </div>
      <div style="background:#fff;border:1px solid #e5e7eb;border-top:none;padding:24px;border-radius:0 0 8px 8px">
        <p style="color:#374151"><strong>${toName}</strong>님, 긴급 알림이 <strong>${hoursUnresolved}시간째</strong> 미처리 상태입니다.</p>
        <div style="background:#fef9c3;border:1px solid #fde68a;border-radius:8px;padding:16px;margin:16px 0">
          <p style="margin:0;color:#78350f"><strong>${memberName}</strong> · ${district}</p>
          <p style="margin:6px 0 0;color:#92400e">${message}</p>
        </div>
        <a href="http://localhost:3000/alerts" style="display:inline-block;background:#d97706;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;font-weight:600">즉시 처리하기</a>
        <p style="color:#9ca3af;font-size:12px;margin-top:20px">온결 관리자 시스템 · 자동 에스컬레이션</p>
      </div>
    </div>
  `;

  try {
    await transporter.sendMail({
      from:    process.env.MAIL_FROM || process.env.MAIL_USER,
      to:      toEmail,
      subject: `[온결 에스컬레이션] ${memberName}님 알림 ${hoursUnresolved}시간 미처리`,
      html,
    });
    console.log(`📧 에스컬레이션 이메일 발송 → ${toEmail}`);
  } catch (err) {
    console.warn('📧 에스컬레이션 이메일 발송 실패:', err.message);
  }
}

// ── 보호자 긴급 알림 이메일 ──
async function sendGuardianEmail({ toEmail, toName, relation, memberName, district, alertType, message }) {
  if (!process.env.MAIL_USER || !process.env.MAIL_PASS) {
    console.log('📧 이메일 설정 없음 — 보호자 알림 건너뜀');
    return;
  }

  const ALERT_LABELS = {
    no_movement:      '움직임 미감지',
    fall_detected:    '낙상 감지',
    sos:              'SOS 호출',
    low_battery:      '배터리 부족',
    offline:          '기기 오프라인',
    abnormal_pattern: '이상 패턴 감지',
  };

  const subject = `[긴급] ${memberName}님 안전 확인 필요 — 온결 시스템`;

  const html = `
    <div style="font-family:sans-serif;max-width:560px;margin:0 auto">
      <div style="background:#dc2626;padding:16px 24px;border-radius:8px 8px 0 0">
        <h2 style="color:#fff;margin:0;font-size:18px">🚨 긴급 안전 알림</h2>
      </div>
      <div style="background:#fff;border:1px solid #e5e7eb;border-top:none;padding:24px;border-radius:0 0 8px 8px">
        <p style="color:#374151;margin:0 0 16px">
          안녕하세요, <strong>${toName}</strong>님 (${memberName}님의 ${relation || '보호자'}).<br>
          온결 독거 노인 안전 지원 시스템에서 긴급 알림을 보내드립니다.
        </p>

        <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:16px;margin-bottom:20px">
          <p style="margin:0 0 8px;font-weight:700;color:#b91c1c;font-size:15px">⚠️ ${ALERT_LABELS[alertType] || alertType}</p>
          <table style="width:100%;border-collapse:collapse">
            <tr><td style="color:#6b7280;padding:4px 0;width:80px">대상자</td><td style="font-weight:700;color:#111">${memberName}</td></tr>
            <tr><td style="color:#6b7280;padding:4px 0">지역</td><td style="color:#374151">${district}</td></tr>
            <tr><td style="color:#6b7280;padding:4px 0">상황</td><td style="color:#b91c1c;font-weight:600">${message}</td></tr>
          </table>
        </div>

        <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:14px;margin-bottom:20px">
          <p style="margin:0;color:#92400e;font-size:13px">
            📞 담당 복지사 또는 119에 연락하시거나, 직접 방문하여 ${memberName}님의 안전을 확인해 주세요.
          </p>
        </div>

        <p style="color:#9ca3af;font-size:12px;margin:0">
          본 메일은 온결 독거 노인 안전 지원 시스템에서 자동 발송됩니다.<br>
          문의: ${process.env.ADMIN_EMAIL || 'admin@ongyeol.go.kr'}
        </p>
      </div>
    </div>
  `;

  try {
    await transporter.sendMail({
      from:    process.env.MAIL_FROM || process.env.MAIL_USER,
      to:      toEmail,
      subject,
      html,
    });
    console.log(`📧 보호자 이메일 발송 완료 → ${toEmail} (${memberName}님 보호자)`);
  } catch (err) {
    console.warn(`📧 보호자 이메일 발송 실패 (${toEmail}):`, err.message);
  }
}

module.exports = { sendAlertEmail, sendApprovalEmail, sendEscalationEmail, sendGuardianEmail };
