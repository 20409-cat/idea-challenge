const cron = require('node-cron');
const pool = require('../config/database');
const { sendEscalationEmail, sendGuardianEmail } = require('../utils/mailer');
const { sendPushToAll } = require('../routes/push');

// ============================================
// 미처리 알림 자동 관리 크론잡
// ============================================

// 1시간마다 실행
const escalationJob = cron.schedule('0 * * * *', async () => {
  console.log('🔄 [CRON] 미처리 알림 점검 시작...');
  try {
    // 1시간 이상 미처리 critical 알림 조회
    const [unresolvedAlerts] = await pool.query(`
      SELECT
        a.id, a.member_id, a.alert_type, a.message, a.severity, a.created_at,
        m.name AS member_name, m.district, m.risk_level,
        adm.name AS worker_name, adm.email AS worker_email,
        TIMESTAMPDIFF(HOUR, a.created_at, NOW()) AS hours_unresolved
      FROM alerts a
      JOIN members m ON m.id = a.member_id
      LEFT JOIN admins adm ON adm.id = m.assigned_welfare_worker_id
      WHERE a.is_resolved = 0
        AND a.severity = 'critical'
        AND a.created_at < NOW() - INTERVAL 1 HOUR
      ORDER BY a.created_at ASC
    `);

    if (unresolvedAlerts.length === 0) {
      console.log('✅ [CRON] 미처리 긴급 알림 없음');
      return;
    }

    console.log(`⚠️  [CRON] 미처리 긴급 알림 ${unresolvedAlerts.length}건 발견`);

    for (const alert of unresolvedAlerts) {
      const h = alert.hours_unresolved;

      // 위험도를 red로 자동 상향
      if (alert.risk_level !== 'red') {
        await pool.query(
          'UPDATE members SET risk_level = ? WHERE id = ?',
          ['red', alert.member_id]
        );
        console.log(`🔴 [CRON] ${alert.member_name} 위험도 → RED 자동 상향`);
      }

      // 1시간, 3시간, 6시간, 12시간마다 에스컬레이션
      if ([1, 3, 6, 12].includes(h)) {
        // 담당 복지사에게 이메일
        if (alert.worker_email) {
          await sendEscalationEmail({
            toEmail:         alert.worker_email,
            toName:          alert.worker_name || '담당자',
            memberName:      alert.member_name,
            district:        alert.district,
            message:         alert.message,
            hoursUnresolved: h,
          });
        }

        // 보호자에게도 이메일 (6시간, 12시간은 보호자까지)
        if ([6, 12].includes(h)) {
          const [[memberInfo]] = await pool.query(
            `SELECT emergency_contact_name, emergency_contact_email, emergency_contact_relation
             FROM members WHERE id = ?`, [alert.member_id]
          );
          if (memberInfo?.emergency_contact_email) {
            await sendGuardianEmail({
              toEmail:   memberInfo.emergency_contact_email,
              toName:    memberInfo.emergency_contact_name,
              relation:  memberInfo.emergency_contact_relation,
              memberName: alert.member_name,
              district:  alert.district,
              alertType: alert.alert_type,
              message:   `${h}시간째 미처리 상태 — ${alert.message}`,
            });
          }
        }

        // 전체 관리자에게 푸시 알림
        try {
          await sendPushToAll({
            title: `⚠️ ${h}시간 미처리 — ${alert.member_name}님`,
            body:  `${alert.district} · ${alert.message}`,
            icon:  '/icon-192.png',
            tag:   `escalation-${alert.id}`,
            url:   '/alerts',
          });
        } catch (e) { /* 푸시 미설정 무시 */ }

        // 에스컬레이션 로그 기록
        await pool.query(
          `INSERT INTO incident_logs
            (alert_id, member_id, action_taken, outcome)
           VALUES (?, ?, ?, ?)`,
          [
            alert.id,
            alert.member_id,
            `${h}시간 미처리로 자동 에스컬레이션 실행`,
            '자동 처리',
          ]
        );
      }

      // 24시간 이상 미처리 → 자동 조치 완료 처리 + 로그
      if (h >= 24) {
        await pool.query(
          `UPDATE alerts
           SET is_resolved = 1, resolved_at = NOW(), resolution_note = ?
           WHERE id = ?`,
          ['24시간 미처리로 시스템 자동 종료 처리', alert.id]
        );
        await pool.query(
          `INSERT INTO incident_logs
            (alert_id, member_id, action_taken, contacted_emergency, outcome)
           VALUES (?, ?, ?, 1, ?)`,
          [
            alert.id,
            alert.member_id,
            '24시간 미처리 — 시스템 자동 종료 및 비상 연락처 알림 권고',
            '자동 종료',
          ]
        );
        console.log(`🔒 [CRON] ${alert.member_name} 알림 24시간 미처리 → 자동 종료`);
      }
    }

    console.log('✅ [CRON] 미처리 알림 점검 완료');
  } catch (err) {
    console.error('❌ [CRON] 에스컬레이션 오류:', err.message);
  }
}, { timezone: 'Asia/Seoul' });

// 매일 자정 — 오늘 웰니스 리포트 없는 수혜자 체크
const wellnessCheckJob = cron.schedule('0 0 * * *', async () => {
  console.log('🔄 [CRON] 웰니스 리포트 점검...');
  try {
    const [missing] = await pool.query(`
      SELECT m.id, m.name, m.district
      FROM members m
      WHERE m.is_active = 1
        AND m.id NOT IN (
          SELECT member_id FROM wellness_reports
          WHERE report_date = CURDATE()
        )
    `);

    for (const m of missing) {
      // 웰니스 리포트 누락 → warning 알림 자동 생성
      const [existing] = await pool.query(
        `SELECT id FROM alerts
         WHERE member_id = ? AND alert_type = 'no_wellness_report'
           AND DATE(created_at) = CURDATE() AND is_resolved = 0`,
        [m.id]
      );
      if (existing.length === 0) {
        await pool.query(
          `INSERT INTO alerts (member_id, alert_type, severity, message)
           VALUES (?, 'no_wellness_report', 'warning', ?)`,
          [m.id, `${m.name}님의 오늘 웰니스 리포트가 생성되지 않았습니다.`]
        );
        console.log(`⚠️  [CRON] ${m.name} 웰니스 리포트 누락 알림 생성`);
      }
    }
  } catch (err) {
    console.error('❌ [CRON] 웰니스 점검 오류:', err.message);
  }
}, { timezone: 'Asia/Seoul' });

module.exports = { escalationJob, wellnessCheckJob };
