const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config();

// DB 없이 먼저 연결해서 DB 자체를 생성
async function initDatabase() {
  // 1단계: DB 생성 (없으면)
  const rootConn = await mysql.createConnection({
    host:     process.env.DB_HOST     || 'localhost',
    port:     parseInt(process.env.DB_PORT) || 3306,
    user:     process.env.DB_USER     || 'root',
    password: process.env.DB_PASSWORD || '',
    charset:  'utf8mb4',
  });

  await rootConn.query(
    `CREATE DATABASE IF NOT EXISTS \`${process.env.DB_NAME || 'ongyeol_db'}\`
     CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
  );
  console.log(`✅ 데이터베이스 '${process.env.DB_NAME || 'ongyeol_db'}' 준비 완료`);
  await rootConn.end();

  // 2단계: 해당 DB에 연결해서 테이블 생성
  const conn = await mysql.createConnection({
    host:     process.env.DB_HOST     || 'localhost',
    port:     parseInt(process.env.DB_PORT) || 3306,
    database: process.env.DB_NAME     || 'ongyeol_db',
    user:     process.env.DB_USER     || 'root',
    password: process.env.DB_PASSWORD || '',
    charset:  'utf8mb4',
    multipleStatements: true,
  });

  const schema = `
-- ============================================
-- 온결 관리자 시스템 — MySQL 스키마
-- ============================================

CREATE TABLE IF NOT EXISTS admins (
  id           CHAR(36)      PRIMARY KEY DEFAULT (UUID()),
  email        VARCHAR(100)  UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name         VARCHAR(50)   NOT NULL,
  role         ENUM('super_admin','local_gov','welfare_worker') NOT NULL DEFAULT 'welfare_worker',
  department   VARCHAR(100),
  phone        VARCHAR(20),
  is_active    TINYINT(1)    NOT NULL DEFAULT 1,
  last_login   DATETIME,
  created_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS members (
  id                          CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
  name                        VARCHAR(50)  NOT NULL,
  birth_date                  DATE         NOT NULL,
  gender                      ENUM('male','female'),
  address                     TEXT         NOT NULL,
  district                    VARCHAR(50)  NOT NULL,
  phone                       VARCHAR(20),
  medical_notes               TEXT,
  emergency_contact_name      VARCHAR(50),
  emergency_contact_phone     VARCHAR(20),
  emergency_contact_relation  VARCHAR(30),
  assigned_welfare_worker_id  CHAR(36),
  risk_level                  ENUM('red','yellow','green') NOT NULL DEFAULT 'green',
  is_active                   TINYINT(1)   NOT NULL DEFAULT 1,
  registered_at               DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at                  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (assigned_welfare_worker_id) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS devices (
  id               CHAR(36)     PRIMARY KEY DEFAULT (UUID()),
  device_serial    VARCHAR(100) UNIQUE NOT NULL,
  member_id        CHAR(36),
  battery_level    TINYINT UNSIGNED,
  is_online        TINYINT(1)   NOT NULL DEFAULT 0,
  last_ping        DATETIME,
  location_in_home VARCHAR(50),
  firmware_version VARCHAR(20),
  installed_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS wellness_reports (
  id              CHAR(36)   PRIMARY KEY DEFAULT (UUID()),
  member_id       CHAR(36)   NOT NULL,
  report_date     DATE       NOT NULL,
  sleep_score     TINYINT,
  activity_score  TINYINT,
  meal_score      TINYINT,
  overall_score   TINYINT,
  ai_summary      TEXT,
  generated_at    DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS alerts (
  id               CHAR(36)    PRIMARY KEY DEFAULT (UUID()),
  member_id        CHAR(36)    NOT NULL,
  device_id        CHAR(36),
  alert_type       VARCHAR(50) NOT NULL,
  severity         ENUM('critical','warning','info') NOT NULL,
  message          TEXT        NOT NULL,
  is_resolved      TINYINT(1)  NOT NULL DEFAULT 0,
  resolved_by      CHAR(36),
  resolved_at      DATETIME,
  resolution_note  TEXT,
  created_at       DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (member_id)   REFERENCES members(id) ON DELETE CASCADE,
  FOREIGN KEY (resolved_by) REFERENCES admins(id)  ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS incident_logs (
  id                  CHAR(36)   PRIMARY KEY DEFAULT (UUID()),
  alert_id            CHAR(36),
  member_id           CHAR(36)   NOT NULL,
  handled_by          CHAR(36),
  action_taken        TEXT       NOT NULL,
  contacted_emergency TINYINT(1) NOT NULL DEFAULT 0,
  visit_required      TINYINT(1) NOT NULL DEFAULT 0,
  outcome             VARCHAR(100),
  logged_at           DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (member_id)  REFERENCES members(id) ON DELETE CASCADE,
  FOREIGN KEY (handled_by) REFERENCES admins(id)  ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. 웹 푸시 구독 정보
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id         INT          PRIMARY KEY AUTO_INCREMENT,
  admin_id   CHAR(36)     NOT NULL,
  subscription TEXT       NOT NULL,
  updated_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_admin (admin_id),
  FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 인덱스
CREATE INDEX IF NOT EXISTS idx_members_risk    ON members(risk_level);
CREATE INDEX IF NOT EXISTS idx_members_district ON members(district);
CREATE INDEX IF NOT EXISTS idx_alerts_severity  ON alerts(severity);
CREATE INDEX IF NOT EXISTS idx_alerts_resolved  ON alerts(is_resolved);
CREATE INDEX IF NOT EXISTS idx_devices_member   ON devices(member_id);
`;

  await conn.query(schema);
  console.log('✅ 테이블 생성 완료');

  // 초기 관리자 계정
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@ongyeol.go.kr';
  const adminPw    = process.env.ADMIN_PASSWORD || 'Admin1234!';

  const [existing] = await conn.query('SELECT id FROM admins WHERE email = ?', [adminEmail]);
  if (existing.length === 0) {
    const hash = await bcrypt.hash(adminPw, 12);
    await conn.query(
      `INSERT INTO admins (id, email, password_hash, name, role, department)
       VALUES (UUID(), ?, ?, '시스템 관리자', 'super_admin', '온결 운영팀')`,
      [adminEmail, hash]
    );
    console.log(`✅ 초기 관리자 계정 생성: ${adminEmail}`);
  } else {
    console.log('ℹ️  관리자 계정 이미 존재');
  }

  // 샘플 데이터 (개발 환경)
  if (process.env.NODE_ENV !== 'production') {
    const [cnt] = await conn.query('SELECT COUNT(*) AS c FROM members');
    if (cnt[0].c === 0) {
      await seedSampleData(conn);
    }
  }

  await conn.end();
  console.log('\n🎉 데이터베이스 초기화 완료!');
  console.log(`   로그인 → ${adminEmail} / ${adminPw}`);
}

async function seedSampleData(conn) {
  console.log('🌱 샘플 데이터 삽입 중...');

  const workerHash = await bcrypt.hash('Worker1234!', 12);
  await conn.query(
    `INSERT INTO admins (id, email, password_hash, name, role, department, phone)
     VALUES (UUID(), 'worker1@ongyeol.go.kr', ?, '김복지', 'welfare_worker', '독거노인지원팀', '051-000-0001')`,
    [workerHash]
  );
  const [[worker]] = await conn.query("SELECT id FROM admins WHERE email = 'worker1@ongyeol.go.kr'");

  const members = [
    { name:'이순자', birth:'1942-03-15', addr:'부산시 해운대구 좌동 123',  district:'해운대구', risk:'red',    phone:'010-1111-2222', notes:'고혈압, 당뇨' },
    { name:'박영감', birth:'1938-07-22', addr:'부산시 동래구 온천동 45',   district:'동래구',   risk:'yellow', phone:'010-3333-4444', notes:'관절염' },
    { name:'최할머니',birth:'1945-11-08',addr:'부산시 사하구 신평동 89',   district:'사하구',   risk:'green',  phone:'010-5555-6666', notes:'' },
    { name:'강노인', birth:'1950-05-30', addr:'부산시 북구 화명동 201',    district:'북구',     risk:'yellow', phone:'010-7777-8888', notes:'심장질환' },
    { name:'오말순', birth:'1935-09-14', addr:'부산시 수영구 광안동 77',   district:'수영구',   risk:'green',  phone:'010-9999-0000', notes:'' },
  ];

  for (const m of members) {
    await conn.query(
      `INSERT INTO members
        (id, name, birth_date, gender, address, district, phone, medical_notes,
         emergency_contact_name, emergency_contact_phone, emergency_contact_relation,
         assigned_welfare_worker_id, risk_level)
       VALUES (UUID(),?,?,?,?,?,?,?,'가족','010-0000-1111','자녀',?,'${m.risk}')`,
      [m.name, m.birth, 'female', m.addr, m.district, m.phone, m.notes, worker.id]
    );

    const [[mem]] = await conn.query('SELECT id FROM members WHERE name = ? ORDER BY registered_at DESC LIMIT 1', [m.name]);

    const serial = `OG-STICK-${Math.random().toString(36).substring(2,8).toUpperCase()}`;
    const bat    = Math.floor(Math.random()*40)+60;
    const online = Math.random() > 0.2 ? 1 : 0;
    await conn.query(
      `INSERT INTO devices (id, device_serial, member_id, battery_level, is_online, last_ping, location_in_home, firmware_version)
       VALUES (UUID(),?,?,?,?,NOW(),'거실','1.2.0')`,
      [serial, mem.id, bat, online]
    );

    await conn.query(
      `INSERT INTO wellness_reports (id, member_id, report_date, sleep_score, activity_score, meal_score, overall_score, ai_summary)
       VALUES (UUID(),?,CURDATE(),?,?,?,?,'전반적으로 안정적인 생활 패턴을 유지하고 있습니다.')`,
      [mem.id,
       Math.floor(Math.random()*30)+60,
       Math.floor(Math.random()*30)+55,
       Math.floor(Math.random()*30)+60,
       Math.floor(Math.random()*30)+58]
    );
    console.log(`  ✅ ${m.name} 등록`);
  }

  // 샘플 알림
  const [[firstMember]] = await conn.query('SELECT id FROM members LIMIT 1');
  await conn.query(
    `INSERT INTO alerts (id, member_id, alert_type, severity, message)
     VALUES (UUID(), ?, 'no_movement', 'critical', '8시간 이상 움직임이 감지되지 않습니다.')`,
    [firstMember.id]
  );
  console.log('✅ 샘플 데이터 완료');
}

initDatabase()
  .then(() => process.exit(0))
  .catch(err => { console.error('❌ 오류:', err.message); process.exit(1); });
