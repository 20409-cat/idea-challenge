const jwt = require('jsonwebtoken');
const pool = require('../config/database');

const authMiddleware = async (req, res, next) => {
  try {
    const header = req.headers.authorization;
    if (!header?.startsWith('Bearer '))
      return res.status(401).json({ error: '인증 토큰이 필요합니다.' });

    const decoded = jwt.verify(header.split(' ')[1], process.env.JWT_SECRET);

    const [rows] = await pool.query(
      'SELECT id, email, name, role, department, is_active FROM admins WHERE id = ?',
      [decoded.id]
    );

    if (!rows.length || !rows[0].is_active)
      return res.status(401).json({ error: '유효하지 않은 계정입니다.' });

    req.user = rows[0];
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError')
      return res.status(401).json({ error: '토큰이 만료되었습니다. 다시 로그인하세요.' });
    return res.status(401).json({ error: '인증에 실패했습니다.' });
  }
};

const requireRole = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role))
    return res.status(403).json({ error: '접근 권한이 없습니다.' });
  next();
};

module.exports = { authMiddleware, requireRole };
