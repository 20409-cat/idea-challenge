const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT) || 3306,
  database: process.env.DB_NAME     || 'ongyeol_db',
  user:     process.env.DB_USER     || 'root',
  password: process.env.DB_PASSWORD || '',
  waitForConnections: true,
  connectionLimit: 10,
  charset: 'utf8mb4',
  timezone: '+09:00',
});

// 연결 테스트
pool.getConnection()
  .then(conn => {
    console.log('✅ MySQL(XAMPP) 연결 성공');
    conn.release();
  })
  .catch(err => {
    console.error('❌ MySQL 연결 실패:', err.message);
    console.error('   → XAMPP에서 MySQL이 실행 중인지 확인하세요.');
  });

module.exports = pool;
