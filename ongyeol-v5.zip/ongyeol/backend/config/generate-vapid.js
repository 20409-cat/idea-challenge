/**
 * VAPID 키 생성 스크립트
 * 실행: node config/generate-vapid.js
 * 출력된 키를 backend/.env 에 붙여넣으세요
 */
const webpush = require('web-push');

const keys = webpush.generateVAPIDKeys();

console.log('\n✅ VAPID 키 생성 완료!\n');
console.log('아래 내용을 backend/.env 파일에 추가하세요:\n');
console.log(`VAPID_PUBLIC_KEY=${keys.publicKey}`);
console.log(`VAPID_PRIVATE_KEY=${keys.privateKey}`);
console.log('\n프론트엔드 .env 파일에도 추가하세요:\n');
console.log(`REACT_APP_VAPID_PUBLIC_KEY=${keys.publicKey}`);
console.log('\n⚠️  VAPID_PRIVATE_KEY는 절대 외부에 공개하지 마세요!\n');
