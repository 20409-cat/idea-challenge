const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const morgan  = require('morgan');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app  = express();
const PORT = process.env.PORT || 4000;

app.use(helmet());
app.use(cors({
  origin: ['http://localhost:3000', 'http://127.0.0.1:3000'],
  credentials: true,
}));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 300,
  message: { error: '요청이 너무 많습니다. 잠시 후 다시 시도하세요.' } }));
app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));

app.use('/api/auth',      require('./routes/auth'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/members',   require('./routes/members'));
app.use('/api/alerts',    require('./routes/alerts'));
app.use('/api/push',      require('./routes/push').router);

app.get('/api/health', (req, res) =>
  res.json({ status: 'ok', db: 'MySQL(XAMPP)', time: new Date().toISOString() })
);

app.use('*', (req, res) => res.status(404).json({ error: '경로를 찾을 수 없습니다.' }));
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: '서버 오류' }); });

app.listen(PORT, () => {
  console.log(`
╔═════════════════════════════════════════╗
║   온결 관리자 시스템 — XAMPP MySQL 백엔드  ║
║   http://localhost:${PORT}                ║
╚═════════════════════════════════════════╝`);

  // 자동 스케줄러 시작
  const { escalationJob, wellnessCheckJob } = require('./utils/scheduler');
  escalationJob.start();
  wellnessCheckJob.start();
  console.log('⏰ 자동 스케줄러 시작 (미처리 알림 자동 관리)');
});
